import os

os.system("py manage.py process_tasks & py manage.py runserver") 