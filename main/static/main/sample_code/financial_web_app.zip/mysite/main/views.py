from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import Tutorial, TutorialCategory, TutorialSeries, Screener, ComponentFeatures, Portfolio, TickerPlot, IndexPlot, Simulation, IndexPrices, ComponentPrices, SimulationHistory, SimulationSummary
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth import login, logout, authenticate
from django.contrib import messages
from .forms import NewUserForm, ScreenerForm, PortfolioForm, SimulationForm
import pandas as pd
from django.views.generic import TemplateView
from .python.screener_table import create_screener_table, create_portfolio_table, create_simulation_table, create_simulation_history_table
from .visualisations.bokeh_plots import bokeh_plot
import json
from .tasks import component_features
from datetime import date
import os
from .filters import ScreenerFilter
from .python.generate_simulation_history import generate_simulation_history, generate_simulation_summary

path = r"C:\Users\adsk1\Documents\Coding portfolio\mysite\main\python\\"

os.chdir(path)

current_df = pd.read_csv(r"C:\Users\adsk1\Documents\Coding portfolio\Investment_project\current_features_FTSE_100.csv")
#index_df = pd.read_csv("index_prices.csv")
#historical_component_prices_df = pd.read_csv("component_prices.csv")

#

def single_slug(request, single_slug):
    # first check to see if the url is in categories.
    #print(single_slug)

    categories = [c.category_slug for c in TutorialCategory.objects.all()]
    if single_slug in categories:
        matching_series = TutorialSeries.objects.filter(tutorial_category__category_slug=single_slug)
        series_urls = {}

        for m in matching_series.all():
            part_one = Tutorial.objects.filter(tutorial_series__tutorial_series=m.tutorial_series).earliest("tutorial_published")
            series_urls[m] = part_one.tutorial_slug

        return render(request=request,
                      template_name='main/category.html',
                      context={"tutorial_series": matching_series, "part_ones": series_urls})
                      
    tutorials = [t.tutorial_slug for t in Tutorial.objects.all()]
    if single_slug in tutorials:
        this_tutorial = Tutorial.objects.get(tutorial_slug = single_slug)
        
        tutorials_from_series = Tutorial.objects.filter(tutorial_series__tutorial_series=this_tutorial.tutorial_series).order_by("tutorial_published")
        this_tutorial_idx = list(tutorials_from_series).index(this_tutorial)
        
        return render(request,
                      "main/tutorial.html",
                      {"tutorial":this_tutorial,
                       "sidebar": tutorials_from_series,
                       "this_tutorial_idx": this_tutorial_idx})
    
    ticker_list = [t.ticker_slug for t in ComponentFeatures.objects.all()]
    if single_slug in ticker_list:
        ticker_object = ComponentFeatures.objects.filter(ticker_slug = single_slug,
                                                         date = date.today())
        print(ticker_object)
        ticker_object = ticker_object.last()
        Ticker = ticker_object.ticker
        
        ticker_plot = TickerPlot.objects.filter(ticker = Ticker)
        
        ticker_plot = ticker_plot.all().last()
        
        return render(request,
                      "main/ticker_page.html",
                      {"ticker_object":ticker_object,
                       "ticker_plot":ticker_plot})
        
    return HttpResponse(f"{single_slug} does not correspond to anything.")

# Create your views here.
def homepage(request):
    Index_plot = IndexPlot.objects.all().first()
    return render(request=request,
                  template_name='main/home.html',
                  context={'Index_plot':Index_plot})
                  
def portfolio(request):
    if request.method == "POST" and 'Add' in request.POST:
        
        form = PortfolioForm(request.POST)
        if form.is_valid():
        
            fs= form.save(commit=False)
            fs.user = request.user.username
            
            fs.save()
            
            username = fs.user
            
            #for object in Portfolio.objects.all():
                #print(object.user)
            
            portfolio_features = create_portfolio_table(username,ComponentFeatures,Portfolio.objects.all())
        
            #print(Portfolio)
            #table_data,table_columns = create_screener_table(current_df,Screener.objects.all())

        return render(request,
                      template_name = "main/portfolio.html",
                      context={'form':form,
                               'portfolio_features':portfolio_features})
    
    elif request.method == "POST" and 'Subtract' in request.POST:
        
        form = PortfolioForm(request.POST)
        form.save()
        username = request.user.username
        Portfolio.objects.filter(
            ticker=form.cleaned_data.get('ticker'),
            user=username).delete()
        table_data,table_columns = create_portfolio_table(username,current_df,Portfolio.objects.all())
        
        return render(request,
                      template_name = "main/portfolio.html",
                      context={'form':form,
                               'portfolio':Portfolio.objects.all(),
                               'table_data':table_data,
                               'table_columns':table_columns})
        
    else:       
        
        username = request.user.username
        portfolio_features = create_portfolio_table(username,ComponentFeatures,Portfolio.objects.all())
        print(portfolio_features)
    
        form = PortfolioForm()
        return render(request,
                      template_name = "main/portfolio.html",
                      context={'form':form,
                               'portfolio_features':portfolio_features})  
                  
def screener(request):
    if request.method == "POST" and 'Add' in request.POST:
      
        form = ScreenerForm(request.POST)
        #print(form)
        if form.is_valid():
            form.save()
            
            #table_data,table_columns = create_screener_table(current_df,Screener.objects.all())
            
            
        return render(request,
                      template_name = "main/screener.html",
                      context={'form':form,
                               'data':Screener.objects.all()})
                               #'table_data':table_data,
                               #'table_columns':table_columns})
                               
    elif request.method == "POST" and 'Go' in request.POST:
        
        #form = ScreenerForm(request.POST)
        #if form.is_valid():
            #form.save()
        
            
        screener_features = create_screener_table(ComponentFeatures,Screener.objects.all())
            
        form = ScreenerForm()
        return render(request,
                      template_name = "main/screener.html",
                      context={'form':form,
                               'screener_features':screener_features,
                               'data':Screener.objects.all()})
                               
    else:                           
        Screener.objects.all().delete()
        form = ScreenerForm()
        return render(request,
                      template_name = "main/screener.html",
                      context={'form':form})
        
        
def simulation(request):

    if request.method == "POST" and 'Add' in request.POST:
        
        form = SimulationForm(request.POST)
        if form.is_valid():
        
            fs= form.save(commit=False)
            fs.user = request.user.username
            fs.date = date(2020,4,28)
            #fs.date = date.today()
            index_objects = IndexPrices.objects.filter(date = fs.date).all()
            
            for object in index_objects:
            
                fs.index_price = object.adj_close
            
            stock_objects = ComponentPrices.objects.filter(ticker = form.cleaned_data.get('ticker'),
                                                           date = fs.date).all()
                                                           
            for object in stock_objects:
            
                fs.stock_price = object.adj_close
            
            fs.save()
            
            username = fs.user
            
            SimulationHistory.objects.all().delete()
            
            generate_simulation_history(Simulation.objects.all(), ComponentPrices)
            
            generate_simulation_summary(Simulation,SimulationHistory)
            
            print(SimulationHistory.objects.all())

        return render(request,
                      template_name = "main/simulation.html",
                      context={'form':form,
                               'simulation':Simulation.objects.all(),
                               'simulation_history':SimulationHistory.objects.all(),
                               'simulation_summary':SimulationSummary.objects.all()})
                               
    elif request.method == "POST" and 'Subtract' in request.POST:
        
        form = SimulationForm(request.POST)
        form.save()
        username = request.user.username
        Simulation.objects.filter(
            ticker=form.cleaned_data.get('ticker'),
            user=username).delete()
        table_data,table_columns = create_simulation_table(username,current_df,Simulation.objects.all())
        
        return render(request,
                      template_name = "main/simulation.html",
                      context={'form':form,
                               'simulation':Simulation.objects.all(),
                               'table_data':table_data,
                               'table_columns':table_columns})
    
    else:       
        
        username = request.user.username
        #table_data,table_columns = create_simulation_table(username,current_df,Simulation.objects.all())
    
        form = SimulationForm()
        return render(request,
                      template_name = "main/simulation.html",
                      context={'form':form,
                               'simulation':Simulation.objects.all(),
                               'simulation_history':SimulationHistory.objects.all(),
                               'simulation_summary':SimulationSummary.objects.all()})
                               
def register(request):

    if request.method == "POST":
        form = NewUserForm(request.POST)
        if form.is_valid():
            user = form.save()
            username = form.cleaned_data.get('username')
            messages.success(request, f"New Account Created: {username}")
            login(request, user)
            messages.info(request, f"You are now logged in as {username}")
            return redirect("main:homepage")
            
        else:
            for msg in form.error_messages:
                messages.error(request, f"{msg}:{form.error_messages[msg]}")
                
            return render(request = request,
                          template_name = "main/register.html",
                          context={"form":form})
            
            
            
    form = NewUserForm
    return render(request,
                  "main/register.html",
                  context={"form":form})
                  
                  
def logout_request(request):
    logout(request)
    messages.info(request, "Logged out successfully!")
    return redirect("main:homepage")
    
def login_request(request):
    if request.method == "POST":
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                messages.info(request, f"You are now logged in as {username}")
                
                return redirect("main:homepage")
            else:
                messages.error(request, "Invalid username or password")
        else:
                messages.error(request, "Invalid username or password")
        
    form = AuthenticationForm()
    return render(request,
                  "main/login.html",
                  context={"form":form})