import pandas as pd
import os
from datetime import datetime
import plotly.graph_objects as go
import plotly.io as pio

path = r"C:\Users\adsk1\Documents\Coding portfolio\mysite\main\python\\"
os.chdir(path)

index_df = pd.read_csv("index_prices.csv")
risk_df = pd.read_csv("index_risk_data.csv")

df_ohlc = risk_df[['Date','Open','High','Low','Adj Close']]
df_ohlc.index = df_ohlc['Date'].apply(lambda row: datetime.strptime(row, '%Y-%m-%d'))       
df_ohlc.index.name = 'Date'
df_ohlc.rename(columns={'Adj Close':'Close'},inplace=True)

def candlestick_plot():
    try:

        fig = go.Figure(data=[go.Candlestick(x=df_ohlc['Date'],
                        open=df_ohlc['Open'],
                        high=df_ohlc['High'],
                        low=df_ohlc['Low'],
                        close=df_ohlc['Close'])])
        
        html = pio.to_html(fig, full_html=False, include_plotlyjs='cdn')
        
        print(ticker)
    except:
        html = 'N/A'

    return html

def stock_price_plot():
    try:
        fig = go.Figure(data=[go.Scatter(x=df_ohlc['Date'],
                                         y=df_ohlc['Close'])])
                                         
        fig.update_layout(
            title="FTSE 100 Stock Price",
            xaxis_title="Date",
            yaxis_title="Price")
                                         
        html = pio.to_html(fig, full_html=False, include_plotlyjs='cdn')
        
    
    except Exception as ticker:
        html = 'N/A'
        
    return html
             
def SMA_plot():
    try:
        fig = go.Figure(data=[go.Scatter(x=risk_df['Date'],
                                         y=risk_df["SMA (20 days)"])])
                                         
            
        fig.add_trace(go.Candlestick(x=df_ohlc['Date'],
                      open=df_ohlc['Open'],
                      high=df_ohlc['High'],
                      low=df_ohlc['Low'],
                      close=df_ohlc['Close']))
                      
        fig.update_layout(
            title="FTSE 100 Simple Moving Average",
            xaxis_title="Date",
            yaxis_title="SMA (20 days)")
                                         
        html = pio.to_html(fig, full_html=False, include_plotlyjs='cdn')
    
    except Exception as ticker:
        html = 'N/A'   
            
    return html
    
    
def MACD_plot():
    try:
        fig = go.Figure(data=[go.Scatter(x=risk_df['Date'],
                                         y=risk_df['MACD'])])
        
        fig.add_trace(go.Scatter(x=risk_df['Date'],
                                 y=risk_df['MACD signal']))
                                 
        fig.add_trace(go.Scatter(x=risk_df['Date'],
                                 y=risk_df['MACD histogram']))
        
        fig.update_layout(
            title="FTSE 100 Moving Average Convergence Divergence",
            xaxis_title="Date",
            yaxis_title="MACD")
           
                                         
        html = pio.to_html(fig, full_html=False, include_plotlyjs='cdn')
    
    except Exception as ticker:
        html = 'N/A'   
            
    return html
    
    
def RSI_plot():
    try:
        fig = go.Figure(data=[go.Scatter(x=risk_df['Date'],
                                         y=risk_df['RSI two'])])
        
        fig.add_trace(go.Scatter(x=risk_df['Date'],
                                 y = [30] * len(risk_df)))
                                 
        fig.add_trace(go.Scatter(x=risk_df['Date'],
                                 y = [30] * len(risk_df)))
        
        fig.update_layout(
            title="FTSE 100 Relative Strength Index",
            xaxis_title="Date",
            yaxis_title="RSI")
           
                                         
        html = pio.to_html(fig, full_html=False, include_plotlyjs='cdn')
    
    except Exception as ticker:
        html = 'N/A'   
            
    return html
    
    
plotly_df = pd.DataFrame()

candlestick_html = candlestick_plot()
stock_price_html = stock_price_plot()  
SMA_html = SMA_plot()
MACD_html = MACD_plot()
RSI_html = RSI_plot()

plotly_df = plotly_df.append({'Stock price html':stock_price_html,
                              'Candlestick html':candlestick_html,
                              'SMA html':SMA_html,
                              'MACD html':MACD_html,
                              'RSI html':RSI_html},
                              ignore_index=True)
                              
plotly_df.to_csv(r'C:\Users\adsk1\Documents\Coding portfolio\mysite\main\visualisations\index_prices_html.csv') 