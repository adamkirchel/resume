import pandas as pd
import os
from datetime import datetime
import plotly.graph_objects as go
import plotly.io as pio

# Get correct path
path = r"C:\Users\adsk1\Documents\Coding portfolio\mysite\main\python\\"
os.chdir(path)

# Import data
ticker_list = pd.read_csv("ticker_list.csv")
current_df = pd.read_csv("current_features_FTSE_100.csv")
index_df = pd.read_csv("index_prices.csv")
historical_component_prices_df = pd.read_csv("component_prices.csv")
risk_df = pd.read_csv("risk_plots.csv")

df_ohlc = risk_df[['Date','Open','High','Low','Adj Close','Ticker']]
df_ohlc.index = df_ohlc['Date'].apply(lambda row: datetime.strptime(row, '%Y-%m-%d'))       
df_ohlc.index.name = 'Date'
df_ohlc.rename(columns={'Adj Close':'Close'},inplace=True)


def candlestick_plot(ticker):
    try:

        fig = go.Figure(data=[go.Candlestick(x=df_ohlc[df_ohlc["Ticker"]==ticker]['Date'],
                        open=df_ohlc[df_ohlc["Ticker"]==ticker]['Open'],
                        high=df_ohlc[df_ohlc["Ticker"]==ticker]['High'],
                        low=df_ohlc[df_ohlc["Ticker"]==ticker]['Low'],
                        close=df_ohlc[df_ohlc["Ticker"]==ticker]['Close'])])
        
        html = pio.to_html(fig, full_html=False, include_plotlyjs='cdn')
        
        print(ticker)
    except:
        html = 'N/A'

    return html

def stock_price_plot(ticker):
    try:
        fig = go.Figure(data=[go.Scatter(x=df_ohlc[df_ohlc["Ticker"]==ticker]['Date'],
                                         y=df_ohlc[df_ohlc["Ticker"]==ticker]['Close'])])
                                         
        fig.update_layout(
            title=ticker + " Stock Price",
            xaxis_title="Date",
            yaxis_title="Price")
                                         
        html = pio.to_html(fig, full_html=False, include_plotlyjs='cdn')
        
    
    except Exception as ticker:
        html = 'N/A'
        
    return html
             
def SMA_plot(ticker):
    try:
        fig = go.Figure(data=[go.Scatter(x=risk_df[risk_df["Ticker"]==ticker]['Date'],
                                         y=risk_df[risk_df["Ticker"]==ticker]["SMA (20 days)"])])
                                         
            
        fig.add_trace(go.Candlestick(x=df_ohlc['Date'],
                      open=df_ohlc['Open'],
                      high=df_ohlc['High'],
                      low=df_ohlc['Low'],
                      close=df_ohlc['Close']))
                      
        fig.update_layout(
            title=ticker + " Simple Moving Average",
            xaxis_title="Date",
            yaxis_title="SMA (20 days)")
                                         
        html = pio.to_html(fig, full_html=False, include_plotlyjs='cdn')
    
    except Exception as ticker:
        html = 'N/A'   
            
    return html
    
    
def MACD_plot(ticker):
    try:
        fig = go.Figure(data=[go.Scatter(x=risk_df[risk_df["Ticker"]==ticker]['Date'],
                                         y=risk_df[risk_df["Ticker"]==ticker]['MACD'])])
        
        fig.add_trace(go.Scatter(x=risk_df[risk_df["Ticker"]==ticker]['Date'],
                                 y=risk_df[risk_df["Ticker"]==ticker]['MACD signal']))
                                 
        fig.add_trace(go.Scatter(x=risk_df[risk_df["Ticker"]==ticker]['Date'],
                                 y=risk_df[risk_df["Ticker"]==ticker]['MACD histogram']))
        
        fig.update_layout(
            title=ticker + " Moving Average Convergence Divergence",
            xaxis_title="Date",
            yaxis_title="MACD")
           
                                         
        html = pio.to_html(fig, full_html=False, include_plotlyjs='cdn')
    
    except Exception as ticker:
        html = 'N/A'   
            
    return html
    
    
def RSI_plot(ticker):
    try:
        fig = go.Figure(data=[go.Scatter(x=risk_df[risk_df["Ticker"]==ticker]['Date'],
                                         y=risk_df[risk_df["Ticker"]==ticker]['RSI two'])])
        
        fig.add_trace(go.Scatter(x=risk_df[risk_df["Ticker"]==ticker]['Date'],
                                 y = [30] * len(risk_df[risk_df["Ticker"]==ticker])))
                                 
        fig.add_trace(go.Scatter(x=risk_df[risk_df["Ticker"]==ticker]['Date'],
                                 y = [30] * len(risk_df[risk_df["Ticker"]==ticker])))
        
        fig.update_layout(
            title=ticker + " Relative Strength Index",
            xaxis_title="Date",
            yaxis_title="RSI")
           
                                         
        html = pio.to_html(fig, full_html=False, include_plotlyjs='cdn')
    
    except Exception as ticker:
        html = 'N/A'   
            
    return html

 
plotly_df = pd.DataFrame()
SMA_df = pd.DataFrame()

for ticker in ticker_list['Ticker']:
    
    candlestick_html = candlestick_plot(ticker)
    stock_price_html = stock_price_plot(ticker)  
    SMA_html = SMA_plot(ticker)
    MACD_html = MACD_plot(ticker)
    RSI_html = RSI_plot(ticker)

    plotly_df = plotly_df.append({'Ticker':ticker,
                                  'Stock price html':stock_price_html,
                                  'Candlestick html':candlestick_html,
                                  #'SMA html':SMA_html,
                                  'MACD html':MACD_html,
                                  'RSI html':RSI_html},
                                  ignore_index=True)
                                  
    #SMA_df = SMA_df.append({'Ticker':ticker,
    #                        'SMA':SMA_html},
    #                        ignore_index=True)
                            
plotly_df.to_csv(r'C:\Users\adsk1\Documents\Coding portfolio\mysite\main\visualisations\stock_prices_html.csv') 
#SMA_df.to_csv(r'C:\Users\adsk1\Documents\Coding portfolio\mysite\main\visualisations\SMA_html.csv') 

















