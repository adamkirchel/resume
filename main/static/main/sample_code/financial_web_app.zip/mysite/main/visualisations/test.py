import plotly.graph_objects as go
import plotly.io as io
fig = go.Figure(data=go.Bar(y=[2, 3, 1]))
html = io.to_html(fig)
print(html)
