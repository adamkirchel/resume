from bokeh.plotting import figure
from bokeh.embed import components
import json
from bokeh.embed import json_item

def bokeh_plot():

    plot = figure()
    plot.circle([1,2], [3,4])

    script, div = components(plot)
    
    item_text = json.dumps(json_item(plot, "myplot"))
    
    return item_text