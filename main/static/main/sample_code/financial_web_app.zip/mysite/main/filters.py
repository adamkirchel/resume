from django.contrib.auth.models import User
import django_filters
from django import forms
from .models import Screener
import pandas as pd

current_df = pd.read_csv(r"C:\Users\adsk1\Documents\Coding portfolio\Investment_project\current_features_FTSE_100.csv")

features = [(current_df.columns[i],current_df.columns[i]) for i in range(len(current_df.columns))]

class ScreenerFilter(django_filters.FilterSet):
    #feature = forms.CharField(widget=forms.Select(choices=features))
    #maximum = django_filters.NumberFilter(lookup_expr = feature + '__lt')
    #minimum = django_filters.NumberFilter(lookup_expr = feature + '__gt')

    class Meta:
        model = Screener
        fields = ['feature', 'maximum', 'minimum', ]