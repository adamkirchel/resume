from django.db import models
from datetime import datetime,date
from django.contrib.auth.models import User
from django import forms
from django.contrib.auth import get_user_model
from django.utils import timezone



class TutorialCategory(models.Model):

    tutorial_category = models.CharField(max_length=200)
    category_summary = models.CharField(max_length=200)
    category_slug = models.CharField(max_length=200, default=1)

    class Meta:
        # Gives the proper plural name for admin
        verbose_name_plural = "Categories"

    def __str__(self):
        return self.tutorial_category
        

class TutorialSeries(models.Model):
    tutorial_series = models.CharField(max_length=200)

    tutorial_category = models.ForeignKey(TutorialCategory, default=1, verbose_name="Category", on_delete=models.SET_DEFAULT)
    series_summary = models.CharField(max_length=200)

    class Meta:
        # otherwise we get "Tutorial Seriess in admin"
        verbose_name_plural = "Series"

    def __str__(self):
        return self.tutorial_series 

# Create your models here.
class Tutorial(models.Model):
    tutorial_title = models.CharField(max_length=200)
    tutorial_content = models.TextField()
    tutorial_published = models.DateTimeField('date published')
    tutorial_series = models.ForeignKey(TutorialSeries, default=1, verbose_name="Series", on_delete=models.SET_DEFAULT)
    tutorial_slug = models.CharField(max_length=200, default=1)
    def __str__(self):
        return self.tutorial_title
        
class Screener(models.Model):   
    
    feature = models.CharField(max_length=200,default='Price')
    maximum = models.CharField(max_length=200)
    minimum = models.CharField(max_length=200)
    
    #user = models.ForeignKey(User, default=1, on_delete=models.SET_DEFAULT)
    
class Portfolio(models.Model):   
    
    ticker = models.CharField(max_length=200,default='AAL')
    user = models.CharField(max_length=200)
    #user = models.ForeignKey(get_current_user, default=1, verbose_name="Series", on_delete=models.SET_DEFAULT)
    
class ComponentFeatures(models.Model):
    
    date = models.DateField(default = date.today())
    ticker = models.CharField(max_length=200)
    ticker_slug = models.CharField(max_length=200, default=1)
    industry = models.CharField(max_length=200)
    market_cap = models.FloatField(max_length=200,null=True)
    enterprise_value = models.FloatField(max_length=200,null=True)
    trailing_PE = models.FloatField(max_length=200,null=True)
    forward_PE = models.FloatField(max_length=200,null=True)
    PEG_ratio = models.FloatField(max_length=200,null=True)
    price_sales = models.FloatField(max_length=200,null=True)
    price_book = models.FloatField(max_length=200,null=True)
    enterprise_value_revenue = models.FloatField(max_length=200,null=True)
    enterprise_value_EBITDA = models.FloatField(max_length=200,null=True)
    profit_margin = models.FloatField(max_length=200,null=True)
    operating_margin = models.FloatField(max_length=200,null=True)
    return_on_assets = models.FloatField(max_length=200,null=True)
    return_on_equity = models.FloatField(max_length=200,null=True)
    revenue = models.FloatField(max_length=200,null=True)
    revenue_per_share = models.FloatField(max_length=200,null=True)
    quarterly_revenue_growth = models.FloatField(max_length=200,null=True)
    gross_profit = models.FloatField(max_length=200,null=True)
    EBITDA = models.FloatField(max_length=200,null=True)
    net_income = models.FloatField(max_length=200,null=True)
    diluted_EPS = models.FloatField(max_length=200,null=True)
    quarterly_earnings_growth = models.FloatField(max_length=200,null=True)
    total_cash = models.FloatField(max_length=200,null=True)
    total_cash_per_share = models.FloatField(max_length=200,null=True)
    total_debt = models.FloatField(max_length=200,null=True)
    current_ratio = models.FloatField(max_length=200,null=True)
    book_value_per_share = models.FloatField(max_length=200,null=True)
    operating_cash_flow = models.FloatField(max_length=200,null=True)
    levered_free_cash_flow = models.FloatField(max_length=200,null=True)
    
    
    
    #user = models.ForeignKey(User, default=1, on_delete=models.SET_DEFAULT)
    
    class Meta:
        # otherwise we get "Tutorial Seriess in admin"
        verbose_name_plural = "Ticker"

    def __str__(self):
        return self.ticker 
        
class TickerPlot(models.Model):
    
    ticker = models.CharField(max_length=200)
    candlestick_html = models.TextField()
    MACD_html = models.TextField()
    RSI_html = models.TextField()
    stock_html = models.TextField()
    
    class Meta:
        # otherwise we get "Tutorial Seriess in admin"
        verbose_name_plural = "Ticker"

    def __str__(self):
        return self.ticker 
        
class IndexPlot(models.Model):
    
    index = models.TextField()
    candlestick_html = models.TextField()
    SMA_html = models.TextField()
    MACD_html = models.TextField()
    RSI_html = models.TextField()
    stock_html = models.TextField()
    
    class Meta:
        # otherwise we get "Tutorial Seriess in admin"
        verbose_name_plural = "Index"

    def __str__(self):
        return self.index 
        
class Simulation(models.Model):
        
    ticker = models.CharField(max_length=200,null=True)
    investment_amount = models.CharField(max_length=200,null=True)
    user = models.CharField(max_length=200,null=True)
    date = models.DateField(default = date.today())
    stock_price = models.CharField(max_length=200,null=True)
    index_price = models.CharField(max_length=200,null=True)
    
    class Meta:
        # otherwise we get "Tutorial Seriess in admin"
        verbose_name_plural = "Simulation"

    def __str__(self):
        return self.ticker 
        
class SimulationHistory(models.Model):

    investment_number = models.CharField(max_length=200,null=True)
    date =  models.DateField(null=True)
    ticker = models.CharField(max_length=200,null=True)
    initial_investment = models.CharField(max_length=200,null=True)
    current_assets = models.CharField(max_length=200,null=True)
    return_on_investment = models.CharField(max_length=200,null=True)
    percent_change = models.CharField(max_length=200,null=True)
    user = models.CharField(max_length=200,null=True)
    
class SimulationSummary(models.Model):

    ticker = models.CharField(max_length=200,null=True)
    total_amount_invested = models.CharField(max_length=200,null=True)
    total_amount_returned = models.CharField(max_length=200,null=True)
    percentage_yield = models.CharField(max_length=200,null=True)
    profit = models.CharField(max_length=200,null=True)
    
class ComponentPrices(models.Model):

    date = models.DateField(null=True)
    ticker = models.CharField(max_length=200,null=True)
    open = models.CharField(max_length=200,null=True)
    high = models.CharField(max_length=200,null=True)
    low =models.CharField(max_length=200,null=True)
    close = models.CharField(max_length=200,null=True)
    adj_close = models.CharField(max_length=200,null=True)
    volume = models.CharField(max_length=200,null=True)
    
    class Meta:
        # otherwise we get "Tutorial Seriess in admin"
        verbose_name_plural = "ComponentPrices"

    def __str__(self):
        return self.ticker 
        
class IndexPrices(models.Model):

    date = models.DateField(null=True)
    open = models.CharField(max_length=200,null=True)
    high = models.CharField(max_length=200,null=True)
    low = models.CharField(max_length=200,null=True)
    close = models.CharField(max_length=200,null=True)
    adj_close = models.CharField(max_length=200,null=True)
    volume = models.CharField(max_length=200,null=True)
    
    class Meta:
        # otherwise we get "Tutorial Seriess in admin"
        verbose_name_plural = "IndexPrices"

    def __str__(self):
        return str(self.date)
    
        
        