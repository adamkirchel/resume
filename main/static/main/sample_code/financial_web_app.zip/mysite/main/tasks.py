from background_task import background
from django.contrib.auth.models import User
from .python.generate_component_features import current_features
from django.utils import timezone
from datetime import datetime, date
from .models import ComponentFeatures

@background(schedule=5)
def component_features():
    # lookup user by id and send them a message
    #user = User.objects.get(pk=user_id)
    #user.email_user('Here is a notification', 'You have been notified')
    print("Running")
    current_df = current_features()
    
    
    for tick in current_df['Ticker']:
        object = ComponentFeatures(date = date.today(),
                            ticker = tick, 
                            ticker_slug = tick,
                            industry = current_df[current_df['Ticker']==tick]['Industry'].iloc[0],
                            market_cap = current_df[current_df['Ticker']==tick]['Market cap'].iloc[0],
                            enterprise_value = current_df[current_df['Ticker']==tick]['Enterprise value'].iloc[0],
                            trailing_PE = current_df[current_df['Ticker']==tick]['Trailing P/E'].iloc[0],
                            forward_PE = current_df[current_df['Ticker']==tick]['Forward P/E'].iloc[0],
                            PEG_ratio = current_df[current_df['Ticker']==tick]['PEG ratio (5-yr expected)'].iloc[0],
                            price_sales = current_df[current_df['Ticker']==tick]['Price/sales'].iloc[0],
                            price_book = current_df[current_df['Ticker']==tick]['Price/book'].iloc[0],
                            enterprise_value_revenue = current_df[current_df['Ticker']==tick]['Enterprise value/revenue'].iloc[0],
                            enterprise_value_EBITDA = current_df[current_df['Ticker']==tick]['Enterprise value/EBITDA'].iloc[0],
                            profit_margin = current_df[current_df['Ticker']==tick]['Profit margin'].iloc[0],
                            operating_margin = current_df[current_df['Ticker']==tick]['Operating margin'].iloc[0],
                            return_on_assets = current_df[current_df['Ticker']==tick]['Return on assets'].iloc[0],
                            return_on_equity = current_df[current_df['Ticker']==tick]['Return on equity'].iloc[0],
                            revenue = current_df[current_df['Ticker']==tick]['Revenue'].iloc[0],
                            revenue_per_share = current_df[current_df['Ticker']==tick]['Revenue per share'].iloc[0],
                            quarterly_revenue_growth = current_df[current_df['Ticker']==tick]['Quarterly revenue growth'].iloc[0],
                            gross_profit = current_df[current_df['Ticker']==tick]['Gross profit'].iloc[0],
                            EBITDA = current_df[current_df['Ticker']==tick]['EBITDA'].iloc[0],
                            net_income = current_df[current_df['Ticker']==tick]['Net income avi to common'].iloc[0],
                            diluted_EPS = current_df[current_df['Ticker']==tick]['Diluted EPS'].iloc[0], 
                            quarterly_earnings_growth = current_df[current_df['Ticker']==tick]['Quarterly earnings growth'].iloc[0],
                            total_cash = current_df[current_df['Ticker']==tick]['Total cash'].iloc[0],
                            total_cash_per_share = current_df[current_df['Ticker']==tick]['Total cash per share'].iloc[0],
                            total_debt = current_df[current_df['Ticker']==tick]['Total debt'].iloc[0],
                            current_ratio = current_df[current_df['Ticker']==tick]['Current ratio'].iloc[0],
                            book_value_per_share = current_df[current_df['Ticker']==tick]['Book value per share'].iloc[0],
                            operating_cash_flow = current_df[current_df['Ticker']==tick]['Operating cash flow'].iloc[0],
                            levered_free_cash_flow = current_df[current_df['Ticker']==tick]['Levered free cash flow'].iloc[0])
        
        object.save()