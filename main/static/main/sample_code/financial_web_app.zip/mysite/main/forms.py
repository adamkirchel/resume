from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import Screener, Portfolio, Simulation
import pandas as pd

current_df = pd.read_csv(r"C:\Users\adsk1\Documents\Coding portfolio\Investment_project\current_features_FTSE_100.csv")

features = [(current_df.columns[i],current_df.columns[i]) for i in range(len(current_df.columns))]
tickers = [(current_df['Ticker'].iloc[i],current_df['Ticker'].iloc[i]) for i in range(len(current_df))]

class NewUserForm(UserCreationForm):
    email = forms.EmailField(required=True)
    
    class Meta:
        model = User
        fields = ("username", "email", "password1", "password2")
        
    def save(self, commit=True):
        user = super(NewUserForm, self).save(commit=False)
        user.email = self.cleaned_data['email']
        if commit:
            user.save()
        return user
        
class ScreenerForm(forms.ModelForm):
    feature = forms.CharField(widget=forms.Select(choices=features))
    maximum = forms.CharField()
    minimum = forms.CharField()
    
    
    class Meta:
        model = Screener
        fields = ('feature', 'maximum', 'minimum',)
        
class PortfolioForm(forms.ModelForm):
    ticker = forms.CharField(widget=forms.Select(choices=tickers))
    
    class Meta:
        model = Portfolio
        fields = ('ticker',)
        
class SimulationForm(forms.ModelForm):
    ticker = forms.CharField(widget=forms.Select(choices=tickers))
    investment_amount = forms.CharField()
    
    class Meta:
        model = Simulation
        fields = ('ticker','investment_amount',)