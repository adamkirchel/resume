Hi <?php echo htmlspecialchars($_POST['feature']); ?>.
You are <?php echo $_POST['maximum']; ?> years old.
