import urllib.request
import os
import time
import pandas as pd
import csv

def import_FTSE_100():
    path = r"C:\Users\adsk1\Documents\Coding portfolio\Investment_project"
    
    #regex_1 = re.escape(r'>Industry</span><!-- react-text: ')
    #regex_2 = re.escape(r' -->:\xc2\xa0<!-- /react-text --><span class="Fw(600)" data-reactid="')
    #regex_3 = re.escape(r'">')

    #regex = regex_1 + '[0-9]+' + regex_2 + '[0-9]+' + regex_3

    os.chdir(path)
    answer = True
    count = 0
    
    while answer:
        try:
            start_time = str(int(time.time()) - 31540000 - count)
            #print(start_time)
            end_time = str(int(time.time())-count)
            #print(end_time)
                
            link = "https://query1.finance.yahoo.com/v7/finance/download/%5EFTSE?P=FTSE?period1=" + start_time + "&period2=" + end_time + "&interval=1d&events=history"
                
            #resp = urllib.request.urlopen(link).read()

            df = pd.read_csv(link)
            
            answer = False
            
        except:
            count += 1

    
    return df
    
    #df.to_csv(r"C:\Users\adsk1\Documents\Coding portfolio\mysite\main\python\index_prices.csv")

    
#import_FTSE_100()