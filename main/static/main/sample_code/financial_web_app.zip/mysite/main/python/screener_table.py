import pandas as pd
import datetime
import numpy as np
from datetime import date

screener_dict = {'Date' : 'date',
                 'Ticker' : 'Ticker', 
                    'Industry' : 'industry',
                    'Market cap' : 'market_cap',
                    'Enterprise value' : 'enterprise_value',
                    'Trailing P/E' : 'trailing_PE',
                    'Forward P/E' : 'forward_PE',
                    'PEG ratio (5-yr expected)' : 'PEG_ratio',
                    'Price/sales' : 'price_sales',
                    'Price/book' : 'price_book',
                    'Enterprise value/revenue' : 'enterprise_value_revenue',
                    'Enterprise value/EBITDA':'enterprise_value_EBITDA',
                    'Profit margin':'profit_margin',
                    'Operating margin':'operating_margin',
                    'Return on assets':'return_on_assets',
                    'Return on equity':'return_on_equity',
                    'Revenue':'revenue',
                    'Revenue per share':'revenue_per_share',
                    'Quarterly revenue growth':'quarterly_revenue_growth'}
                    #gross_profit = e['Gross profit'],
                    #EBITDA = e['EBITDA'],
                    #net_income = e['Net income avi to common'],
                    #diluted_EPS = e['Diluted EPS'],
                    #quarterly_earnings_growth = e['Quarterly earnings growth'],
                    #total_cash = e['Total cash'],
                    #total_cash_per_share = e['Total cash per share'],
                    #total_debt = e['Total debt'],
                    #current_ratio = e['Current ratio'],
                    #book_value_per_share = e['Book value per share'],
                    #operating_cash_flow = e['Operating cash flow'],
                    #levered_free_cash_flow = e['Levered free cash flow']))}


def create_screener_table(ComponentFeatures,stock_screener_parameters):
	
    
    for object in stock_screener_parameters:
    
        
        feature_lt = screener_dict[object.feature] + '__lt'
        feature_gt = screener_dict[object.feature] + '__gt'
        
        #print(ComponentFeatures)
        try:
            ComponentFeatures = ComponentFeatures.objects.filter(**{feature_lt : object.maximum},
                                                                 **{feature_gt : object.minimum},
                                                                 date = date.today())
        except:
            ComponentFeatures = ComponentFeatures.filter(**{feature_lt : object.maximum},
                                                         **{feature_gt : object.minimum},
                                                         date = date.today())
        
    
        
    return ComponentFeatures
    
    
def create_portfolio_table(username,ComponentFeatures,portfolio_parameters):
	
    portfolio_tickers = [object.ticker for object in portfolio_parameters if object.user == username]
    
    altered_df = ComponentFeatures.objects.filter(date = date.today(),
                                                  ticker__in = portfolio_tickers)
    
    return altered_df
    
def create_simulation_table(username,current_df,simulation_parameters):

    simulation_tickers = [object.ticker for object in simulation_parameters if object.user == username]
    
    altered_df = current_df.apply(lambda row: row if row["Ticker"] in simulation_tickers else row * 0, axis=1)
    
    altered_df = altered_df[altered_df['Ticker'] != '']
    altered_df.dropna(subset = ['Ticker'],inplace=True)
    
    altered_df = altered_df[['Ticker','Industry','Market cap','Revenue']]
    
    return altered_df.values.tolist(), altered_df.columns.tolist()
    
    
def create_simulation_history_table(simulation_objects,historical_component_prices_df):
    portfolio_history_df = pd.DataFrame(columns = ["Investment number","Date","Ticker","Initial amount invested","Current assets","Return on investment","% change"])
    investment_number = 0
	
    for object in simulation_objects:
        
        investment_number = investment_number + 1
        initial_date = object.date
        delta = datetime.timedelta(days=1)
        ticker = object.ticker
        amount_invested = float(object.investment_amount)
        initial_stock_price = float(object.stock_price)

        while initial_date <= datetime.date.today():
            try:
                current_stock_price = historical_component_prices_df[historical_component_prices_df['Date'] == str(initial_date)][historical_component_prices_df['Ticker'] == ticker]['Adj Close'].iloc[0]
                
                percentage_change = current_stock_price/initial_stock_price
                
                current_assets = float(amount_invested) * percentage_change
               
                profit = current_assets - amount_invested
                
                portfolio_history_df = portfolio_history_df.append({"Investment number":investment_number,
                                                                          "Date":initial_date,
                                                                          "Ticker":ticker,
                                                                          "Initial amount invested":amount_invested,
                                                                          "Current assets":current_assets,
                                                                          "Return on investment":profit,
                                                                          "% change":percentage_change},
                                                                          ignore_index = True)
                                                                          
            except:
                pass
            
            initial_date += delta
            
    print(type(portfolio_history_df.values))

    return portfolio_history_df.values.tolist(),portfolio_history_df.columns.tolist()
    #portfolio_history_df.to_csv("portfolio_history.csv")