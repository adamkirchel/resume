import urllib.request
import os
import time
import pandas as pd
import csv
import time
import numpy as np

def import_FTSE_100_component_data():
    path = r"C:\Users\adsk1\Documents\Coding portfolio\Investment_project\Data\FTSE_100_Current_Price\\"
    
    ticker_list = pd.read_csv(r'C:\Users\adsk1\Documents\Coding portfolio\mysite\main\python\ticker_list.csv')
    os.chdir(path)
    
    current_price_list = []
    component_price_df = pd.DataFrame()
    start_time = str(int(time.time()) - 31540000)
    end_time = str(int(time.time()))
    
    
    for ticker in ticker_list['Ticker']:
		
        link = "https://query1.finance.yahoo.com/v7/finance/download/" + ticker + ".L?period1=" + start_time+ "&period2=" + end_time + "&interval=1d&events=history"
        print(ticker)
        #resp = urllib.request.urlopen(link).read()
        
        try:
           
            df = pd.read_csv(link)
            ticker_list = np.array([ticker]*len(df))
            df['Ticker'] = ticker_list
        
            #current_price_list.append(df['Adj Close'][0])
            
            all_dfs = [component_price_df, df]
            component_price_df = pd.concat(all_dfs).reset_index(drop=True)

            #df.to_csv(path + ticker + "_historic_prices.csv")
            
        except:
        
            pass
        
            #current_price_list.append('N/A')
        
   
        
    return component_price_df
    

#import_FTSE_100_component_data()