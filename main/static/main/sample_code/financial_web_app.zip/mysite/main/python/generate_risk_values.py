import pandas as pd
from numpy import mean

def riskPlots():

    risk_df = pd.DataFrame(columns = ["Date",
                                      "Ticker",
                                      "Adj Close",
                                      "Open",
                                      "High",
                                      "Low",
                                      "SMA (20 days)",
                                      "SMA (50 days)",
                                      "SMA (200 days)",
                                      "26 ema","12 ema",
                                      "MACD","MACD signal",
                                      "MACD histogram",
                                      "Gain/Loss",
                                      "Average gain (14 days)",
                                      "Average loss (14 days)",
                                      "RSI one",
                                      "RSI two"])

    index_df = pd.read_csv("component_prices.csv")
    ticker_list = pd.read_csv("ticker_list.csv")
    

    #index_df = index_df.iloc[::-1]
    
    #index_df = index_df.reset_index()
    
    #risk_df["Adj Close"] = index_df["Adj Close"]
    
    for ticker in ticker_list['Ticker']:
    
        gain_loss_list = []
        average_gain_list = []
        average_loss_list = []
        RSI_one_list = []
        RSI_two_list = []
        
        print(ticker)
        
        #print(risk_df["Gain/Loss"])
        
        #print(index_df["Adj Close"].iloc[1]/(index_df["Adj Close"].iloc[2])-1)
        
        for i in range(len(index_df[index_df["Ticker"] == ticker])-1):
        
            diff = ((index_df[index_df["Ticker"] == ticker]["Adj Close"].iloc[i]/(index_df[index_df["Ticker"] == ticker]["Adj Close"].iloc[i+1]))-1)
            #print(diff)
            
            gain_loss_list.append(diff)
        
        for i in range(len(index_df[index_df["Ticker"] == ticker])):
            
           
            average_gain_list.append(abs(mean([x for x in gain_loss_list[i:i+13] if x > 0])))
            #print(risk_df["Gain/Loss"].iloc[range(i,i+13)])
            average_loss_list.append(abs(mean([x for x in gain_loss_list[i:i+13] if x < 0])))
            RSI_one_list.append(100 - (100/(1+(average_gain_list[i]/average_loss_list[i]))))
            
            
            
        
            
        
        for i in range(len(gain_loss_list)):
            if gain_loss_list[i] > 0:
            
                average_gain_2 = ((average_gain_list[i+1]*13)+gain_loss_list[i])/14
                average_loss_2 = ((average_loss_list[i+1]*13))/14
                
            else:
                
                #print(risk_df["Average gain (14 days)"])
                average_gain_2 = ((average_gain_list[i+1]*13))/14
                average_loss_2 = ((average_loss_list[i+1]*13)+gain_loss_list[i])/14
            
            RSI_two_list.append(100 - (100/(1+(average_gain_2/average_loss_2))))
            
        
        ema_26 = index_df[index_df["Ticker"] == ticker]["Adj Close"].ewm(span=26).mean()
        ema_12 = index_df[index_df["Ticker"] == ticker]["Adj Close"].ewm(span=12).mean()
        MACD = ema_12 - ema_26
        MACD_signal = MACD.ewm(span=9).mean()
        MACD_histogram = MACD - MACD_signal
        

        for i in range(len(index_df[index_df["Ticker"] == ticker])):
           
            try:
            #print(gain_loss_list)
                #print((index_df["Adj Close"].iloc[range(i,i+20)].sum())/20)

                risk_df = risk_df.append({"Date":index_df[index_df["Ticker"] == ticker]['Date'].iloc[i],
                                          "Ticker":ticker,
                                          "Adj Close":index_df[index_df["Ticker"] == ticker]['Adj Close'].iloc[i],
                                          "Open":index_df[index_df["Ticker"] == ticker]['Open'].iloc[i],
                                          "High":index_df[index_df["Ticker"] == ticker]['High'].iloc[i],
                                          "Low":index_df[index_df["Ticker"] == ticker]['Low'].iloc[i],
                                          "SMA (20 days)":(index_df[index_df["Ticker"] == ticker]["Adj Close"].iloc[range(i,i+20)].sum())/20,
                                          "SMA (50 days)":(index_df[index_df["Ticker"] == ticker]["Adj Close"].iloc[range(i,i+50)].sum())/50,
                                          "SMA (200 days)":(index_df[index_df["Ticker"] == ticker]["Adj Close"].iloc[range(i,i+200)].sum())/200,
                                          "26 ema":ema_26.iloc[i],
                                          "12 ema":ema_12.iloc[i],
                                          "MACD":MACD.iloc[i],
                                          "MACD signal":MACD_signal.iloc[i],
                                          "MACD histogram":MACD_histogram.iloc[i],
                                          "Gain/Loss":gain_loss_list[i],
                                          "Average gain (14 days)":average_gain_list[i],
                                          "Average loss (14 days)":average_loss_list[i],
                                          "RSI one":RSI_one_list[i],
                                          "RSI two":RSI_two_list[i]},
                                          ignore_index=True)
                
            except:
            
                pass
            
                

        #risk_df["Date"] = index_df["Date"]
        
    risk_df.to_csv("risk_plots.csv")

	
riskPlots()