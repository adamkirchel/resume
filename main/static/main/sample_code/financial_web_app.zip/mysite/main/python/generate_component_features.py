import urllib.request
import os
import time
import csv
import pandas as pd
from time import mktime
import matplotlib
import matplotlib.pyplot as plt
from matplotlib import style
style.use("dark_background")
import numpy as np
from datetime import datetime
import re

path = r"C:\Users\adsk1\Documents\Coding portfolio\Investment_project\Data"

def current_features():

    df = pd.DataFrame(columns = ['Date',
                                     'Unix',
                                     'Ticker',
                                     'Industry',
                                     'Price',
                                     'stock_p_change',
                                     'SP500',
                                     'sp500_p_change',
                                     'Difference',
                                     ##############
                                     "Market cap",
                                    "Enterprise value",
                                    "Trailing P/E",
                                    "Forward P/E",
                                    "PEG ratio (5-yr expected)",
                                    "Price/sales",
                                    "Price/book",
                                    "Enterprise value/revenue",
                                    "Enterprise value/EBITDA",
                                    "Profit margin",
                                    "Operating margin",
                                    "Return on assets",
                                    "Return on equity",
                                    "Revenue",
                                    "Revenue per share",
                                    "Quarterly revenue growth",
                                    "Gross profit",
                                    "EBITDA",
                                    "Net income avi to common",
                                    "Diluted EPS",
                                    "Quarterly earnings growth",
                                    "Total cash",
                                    "Total cash per share",
                                    "Total debt",
                                    "Total debt/equity",
                                    "Current ratio",
                                    "Book value per share",
                                    "Operating cash flow",
                                    "Levered free cash flow",
                                    "Beta (5Y monthly)",
                                    "52-week change",
                                    "S&P500 52-week change",
                                    "52-week high",
                                    "52-week low",
                                    "50-day moving average",
                                    "200-day moving average",
                                    "Avg vol (3-month)",
                                    "Avg vol (10-day)",
                                    "Shares outstanding",
                                    "Float",
                                    "% held by insiders",
                                    "% held by institutions",
                                    "Shares short",
                                    "Short ratio",
                                    "Short % of float",
                                    "Short % of shares outstanding",
                                    "Shares short (prior month )",
                                    "Forward annual dividend rate",
                                    "Forward annual dividend yield",
                                    "Trailing annual dividend rate",
                                    "Trailing annual dividend yield",
                                    "5-year average dividend yield",
                                    "Payout ratio",
                                    "Dividend date",
                                    "Ex-dividend date",
                                    "Last split factor",
                                    "Last split date",
                                    "EPS Rank",
                                    "RPS Rank",
                                    "5 yr Sales",
                                    "5 yr Price",
                                    "Proj Sales",
                                    "Proj Hi/Lo",
                                    "Time Safe",
                                    "STARS Fair Val","Price/cash flow",
                                    "SMA MACD RSI",
                                     ##############
                                     "Status"])
                                     
    gather=["Market cap (intra-day)",
                "Enterprise value",
                "Trailing P/E",
                "Forward P/E",
                "PEG ratio (5-yr expected)",
                "Price/sales",
                "Price/book",
                "Enterprise value/revenue",
                "Enterprise value/EBITDA",
                "Profit margin",
                "Operating margin",
                "Return on assets",
                "Return on equity",
                "Revenue",
                "Revenue per share",
                "Quarterly revenue growth",
                "Gross profit",
                "EBITDA",
                "Net income avi to common",
                "Diluted EPS",
                "Quarterly earnings growth",
                "Total cash",
                "Total cash per share",
                "Total debt",
                "Total debt/equity",
                "Current ratio",
                "Book value per share",
                "Operating cash flow",
                "Levered free cash flow",
                "Beta (5Y monthly)",
                "52-week change",
                "S&P500 52-week change",
                "52-week high",
                "52-week low",
                "50-day moving average",
                "200-day moving average",
                "Avg vol (3-month)",
                "Avg vol (10-day)",
                "Shares outstanding",
                "Float",
                "% held by insiders",
                "% held by institutions",
                "Shares short",
                "Short ratio",
                "Short % of float",
                "Short % of shares outstanding",
                "Shares short (prior month )",
                "Forward annual dividend rate",
                "Forward annual dividend yield",
                "Trailing annual dividend rate",
                "Trailing annual dividend yield",
                "5-year average dividend yield",
                "Payout ratio",
                "Dividend date",
                "Ex-dividend date",
                "Last split factor",
                "Last split date"]
    
    os.chdir(r"C:\Users\adsk1\Documents\Coding portfolio\mysite\main\python\\")
    ticker_list = pd.read_csv('ticker_list.csv')
    

    path = r"C:\Users\adsk1\Documents\Coding portfolio\Investment_project\Data"
    statspath = path+"/FTSE_100_Current_Features"
    #print(ticker_list.iloc[1])

    for ticker in ticker_list['Ticker'][0:]:
        #try:
        #e = e.replace("C:/Users/adsk1/python_3/work/Investment task/intraQuarter/_KeyStats","")
        print(ticker)
        link = "https://uk.finance.yahoo.com/quote/" + ticker + ".L/key-statistics?p=" + ticker + ".L"
        print(link)
        resp = str(urllib.request.urlopen(link).read())
        #print(resp)
        
        
        
        

        #statspath_feature = path+'\FTSE_100_Current_Features'
        #statspath_industry = path+'\FTSE_100_Current_Industries'
        #stock_list = [files for root, dirs, files in os.walk(statspath_feature)]
        #stock_list = stock_list[0]
#print(stock_list)
        
                            


#file_list = os.listdir("")


    
    #full_file_name_feature = statspath_feature + '\\' + each_file
    #full_file_name_industry = statspath_industry + '\\' + each_file
    
    #feature_source = open(full_file_name_feature,"r").read()
    #industry_source = open(full_file_name_industry,"r").read()
    #print(source)
    #print(ticker)
    #print(source)
    


    

        #try:
        value_list = []
    
    #regex_1 = re.escape(r'>Industry</span><!-- react-text: ')
    #regex_2 = re.escape(r' -->:\xc2\xa0<!-- /react-text --><span class="Fw(600)" data-reactid="')
    #regex_3 = re.escape(r'">')

    #regex = regex_1 + '[0-9]+' + regex_2 + '[0-9]+' + regex_3
   
    #industry_marker = r'>Industry</span><!-- react-text: \d*? -->:\xc2\xa0<!-- /react-text --><span class="Fw(600)" data-reactid="\d*?">'
    #each_data_modified = '>' + each_data + '<'
    #regex = r'>Industry</span><!-- react-text: [0-9]+ -->: <!-- /react-text --><span class="Fw\(600\)" data-reactid="[0-9]+">(.*?)<'
    #regex = each_data_modified + r'.*?(\d\.\dM?B?T?|N/A)%?'
    #regex = industry_marker + '(.*?)' + '<'
    #print(industry_source)
    #print(regex)
    #value = re.search(regex + '(.*?)<', industry_source)
    
    #industry = (value.group(1))
    #print(industry)
    
        for each_data in gather:
            try:
        
                each_data_modified = '>' + each_data + '<'
                #each_data_modified = '>' + each_data + '<'
                
                #regex = each_data_modified + r'.*?(\d\.\dM?B?T?|N/A)%?'
                regex = re.escape(each_data_modified) + '.*?(\d{1,8}\.\d{1,8}M?B?T?|N/A)%?' #(\d{1,8}\.\d{1,8}M?B?|N/A)%*
                
                #print(regex)
                value = re.search(regex, resp)
                
                
                
                value = (value.group(1))
                #print(value)
                #print(each_data)
                

                if "B" in value:
                    value = float(value.replace("B",''))*1000000000

                elif "M" in value:
                    value = float(value.replace("M",''))*1000000
                    
                elif "T" in value:
                    value = float(value.replace("T",''))*1000000000000
                    
                elif "N/A" in value:
                    value = np.NaN

                value_list.append(value)
                
                #print(value)
            
            except:
                value = np.NaN
                value_list.append(value)

#if value_list.count("N/A") > 5:
    #pass
#else:
    

        df = df.append({'Date':datetime.now(),
                        'Unix':"N/A",
                        'Ticker':ticker,
                        #'Industry':industry,
                        'Price':"N/A",
                        'stock_p_change':"N/A",
                        'SP500':"N/A",
                        'sp500_p_change':"N/A",
                        'Difference':"N/A",
                        "Market cap":value_list[0],
                        "Enterprise value":value_list[1],
                        "Trailing P/E":value_list[2],
                        "Forward P/E":value_list[3],
                        "PEG ratio (5-yr expected)":value_list[4],
                        "Price/sales":value_list[5],
                        "Price/book":value_list[6],
                        "Enterprise value/revenue":value_list[7],
                        "Enterprise value/EBITDA":value_list[8],
                        "Profit margin":value_list[9],
                        "Operating margin":value_list[10],
                        "Return on assets":value_list[11],
                        "Return on equity":value_list[12],
                        "Revenue":value_list[13],
                        "Revenue per share":value_list[14],
                        "Quarterly revenue growth":value_list[15],
                        "Gross profit":value_list[16],
                        "EBITDA":value_list[17],
                        "Net income avi to common":value_list[18],
                        "Diluted EPS":value_list[19],
                        "Quarterly earnings growth":value_list[20],
                        "Total cash":value_list[21],
                        "Total cash per share":value_list[22],
                        "Total debt":value_list[23],
                        "Total debt/equity":value_list[24],
                        "Current ratio":value_list[25],
                        "Book value per share":value_list[26],
                        "Operating cash flow":value_list[27],
                        "Levered free cash flow":value_list[28],
                        "Beta (5Y monthly)":value_list[29],
                        "52-week change":value_list[30],
                        "S&P500 52-week change":value_list[31],
                        "52-week high":value_list[32],
                        "52-week low":value_list[33],
                        "50-day moving average":value_list[34],
                        "200-day moving average":value_list[35],
                        "Avg vol (3-month)":value_list[36],
                        "Avg vol (10-day)":value_list[37],
                        "Shares outstanding":value_list[38],
                        "Float":value_list[39],
                        "% held by insiders":value_list[40],
                        "% held by institutions":value_list[41],
                        "Shares short":value_list[42],
                        "Short ratio":value_list[43],
                        "Short % of float":value_list[44],
                        "Short % of shares outstanding":value_list[45],
                        "Shares short (prior month )":value_list[46],
                        "Forward annual dividend rate":value_list[47],
                        "Forward annual dividend yield":value_list[48],
                        "Trailing annual dividend rate":value_list[49],
                        "Trailing annual dividend yield":value_list[50],
                        "5-year average dividend yield":value_list[51],
                        "Payout ratio":value_list[52],
                        "Dividend date":value_list[53],
                        "Ex-dividend date":value_list[54],
                        "Last split factor":value_list[55],
                        "Last split date":value_list[56],                         
                        'Status':"N/A"},
                        ignore_index=True)
                        
        
                   
        #except Exception as ticker:
            
        #    print(str(ticker))
            
        #    df = df.append(pd.Series(), ignore_index=True)


        #ranked_df = pd.DataFrame()
    
    
    for feature in df.columns:
    
        ranked_list_arranged = []
    
        ascend_group = ['Timeliness','Forward P/E','Price/book','Price to cash flow']
        NA_group = ['Date','Unix','Ticker','Industry','Price','stock_p_change','SP500','sp500_p_change','Difference','Status','S&P500 52-week change','Shares short','Short ratio','Short % of float','Short % of shares outstanding']
        
        #try:
        
        if feature in ascend_group:
            
            #df[feature] = df[feature].astype('float')
            
            ranked_list = df.sort_values(by = feature,ascending = True)['Ticker']
            ranked_list.reset_index(drop=True,inplace=True)
            
            for ticker in df['Ticker']:
            
                if len(ranked_list.index[ranked_list == ticker]) == 0:
                    ranked_list_arranged.append('')
                else:
                    ranked_list_arranged.append(ranked_list.index[ranked_list == ticker][0])
                
            df[feature + ' rank'] = np.array(ranked_list_arranged)
            
        elif feature in NA_group:
        
            df[feature + ' rank'] = df.apply(lambda row: np.NaN,axis=1)
            #print(len(ranked_df))
        
        else:
            
            #print(df['Market cap'])
            
             
            df[feature] = df[feature].astype('float')
                
                
            #print(feature)
            #print(df.sort_values(by = 'Market cap',ascending = False))
            ranked_list = df.sort_values(by = feature,ascending = False)['Ticker']
            ranked_list.reset_index(drop=True,inplace=True)
            #print(feature)
            #print(ranked_list)
            for ticker in df['Ticker']:
                #print(df['Ticker'])
                
                
                if len(ranked_list.index[ranked_list == ticker]) == 0:
                    ranked_list_arranged.append(np.NaN)
                
                else:
                    ranked_list_arranged.append(ranked_list.index[ranked_list == ticker][0])
            
            #print(len(ranked_df))
            #print(len(ranked_list_arranged))
            #print(np.array(ranked_list_arranged))
            df[feature + ' rank'] = np.array(ranked_list_arranged)
                        
         
            
        
        #df.to_csv("current_features_FTSE_100.csv")
        #ranked_df.to_csv("ranked_current_features_FTSE_100.csv")

        #except Exception as ticker:
        #    print(str(ticker))
        #print(df.head())
        
    return df
    
#df = current_features()
#df.to_csv("current_features_FTSE_100.csv")