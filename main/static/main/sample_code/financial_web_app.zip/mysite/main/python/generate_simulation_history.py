from main.models import SimulationHistory,SimulationSummary
import datetime
from django.db.models import Sum


def generate_simulation_history(simulation_objects, ComponentPrices):
    SimulationHistory.objects.all().delete()
	#portfolio_history_df = pd.DataFrame(columns = ["Investment number","Date","Ticker","Initial amount invested","Current assets","Return on investment","% change"])
    investment_number = 0
    entries = []
    
	
    for object in simulation_objects:
        print(object)
        investment_number = investment_number + 1
        initial_date = object.date
        delta = datetime.timedelta(days=1)
        ticker = object.ticker
        amount_invested = float(object.investment_amount)
        initial_stock_price = float(object.stock_price)
        username = object.user
        
        
        while initial_date <= datetime.date.today():
            
            #try:
            current_stock_price_items = ComponentPrices.objects.filter(date = str(initial_date),
                                                                        ticker = ticker).all()
            for item in current_stock_price_items:
            
                current_stock_price = float(item.adj_close)
                
            percentage_change = current_stock_price/initial_stock_price
            
            current_assets = float(amount_invested) * percentage_change
           
            profit = current_assets - amount_invested
            
            #bulk save

            entries.append(SimulationHistory(investment_number = investment_number,
                                             date = initial_date,
                                             ticker = ticker,
                                             initial_investment = amount_invested,
                                             current_assets = current_assets,
                                             return_on_investment = profit,
                                             percent_change = percentage_change,
                                             user = username))
            
            initial_date += delta
    
    SimulationHistory.objects.bulk_create(entries)
    

def generate_simulation_summary(simulation_objects,simulation_history_objects):  
    #portfolio_calculations_df = pd.DataFrame(columns = ['Ticker','Total amount invested','Total amount returned','% yield','Profit'])
    SimulationSummary.objects.all().delete()
    entries = []       
    for ticker in simulation_objects.objects.values('ticker').distinct():
    
        ticker = ticker['ticker']
    
        ticker_objects = simulation_objects.objects.filter(ticker = ticker)
        ticker_history_objects = simulation_history_objects.objects.filter(ticker = ticker,
                                                                           date = datetime.date.today())
                                                                           
        total_amount_invested = ticker_objects.aggregate(Sum('investment_amount'))['investment_amount__sum']
        total_amount_returned = ticker_history_objects.aggregate(Sum('current_assets'))['current_assets__sum']
        total_profits = ticker_history_objects.aggregate(Sum('return_on_investment'))['return_on_investment__sum']
        percentage_yield = total_amount_returned/total_amount_invested
        
        entries.append(SimulationSummary(ticker = ticker,
                                         total_amount_invested = total_amount_invested,
                                         total_amount_returned = total_amount_returned,
                                         percentage_yield = percentage_yield,
                                         profit = total_profits))
                                         
    SimulationSummary.objects.bulk_create(entries)
                                                                                        
                
                