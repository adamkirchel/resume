import pandas as pd

historical_component_prices_df = pd.read_csv("component_prices.csv")

def simulation_history(simulation_objects):
    portfolio_history_df = pd.DataFrame(columns = ["Investment number","Date","Ticker","Initial amount invested","Current assets","Return on investment","% change"])
    investment_number = 0
	
    for object in simulation_objects:
        
        investment_number = investment_number + 1
        initial_date = object.date
        delta = datetime.timedelta(days=1)
        ticker = object.ticker
        amount_invested = object.investment_amount
        initial_stock_price = object.stock_price

        while initial_date <= datetime.date.today():
            
            current_stock_price = historical_component_prices_df[historical_component_prices_df['Date'] == str(initial_date)][ticker]
            if len(current_stock_price) == 0:
                #print(initial_date)
                pass
                
            else:
                
                current_stock_price = current_stock_price.iloc[0]
                print(current_stock_price)
                #print(self.historical_component_prices_df[self.historical_component_prices_df['Date'] == initial_date])
                percentage_change = current_stock_price/initial_stock_price
                #print(percentage_change)
                current_assets = float(amount_invested) * percentage_change
                profit = current_assets - amount_invested
                
                portfolio_history_df = self.portfolio_history_df.append({"Investment number":investment_number,
                                                                          "Date":initial_date,
                                                                          "Ticker":ticker,
                                                                          "Initial amount invested":amount_invested,
                                                                          "Current assets":current_assets,
                                                                          "Return on investment":profit,
                                                                          "% change":percentage_change},
                                                                          ignore_index = True)
                
            initial_date += delta

    return portfolio_history_df.values.to_list(),portfolio_history_df.columns.to_list()
    #portfolio_history_df.to_csv("portfolio_history.csv")