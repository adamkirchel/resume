function [dz] = stateDeriv3D(t,z)
% Calculates the state derivative for the flight of a shuttlecock
% 
%     dz = stateDeriv3D(t,z) computes the derivative dz = [dx1; dx2; dy1; dy2; dz1; dz2];
%     of the state vector z = [x1;x2;y1;y2;z1;z2] where x1, y1 and z1 are
%     displacements in their respective axes, and x2,y2 and z2 are
%     velocities in their respective axes.

M = 0.005; % Mass (kg)
g = 9.81; % Gravitational acceleration (m/s^2)

% Angles ay and az are calculated
ay = atand(z(6,end)/z(2,end));
az = atand(z(4,end)/((z(2,end))^2 + (z(6,end))^2)^0.5);

% Resultant velocity V is calculated 
V = (((z(2,end))^2 + (z(6,end))^2) + (z(4,end))^2)^0.5;

% Decoupled first-order ODEs
    dx1 = z(2,end);
    dx2 = (drag(t)*((V)^2)/(M))*cosd(az)*cosd(ay);
    dy1 = z(4,end);
    dy2 = - g + ((drag(t)*((V)^2)/M)*sind(az));
    dz1 = z(6,end);
    dz2 = (drag(t)*((V)^2)/(M))*cosd(az)*sind(ay);

% Results from ODEs combined to form vector dz
dz = [dx1; dx2; dy1; dy2; dz1; dz2];