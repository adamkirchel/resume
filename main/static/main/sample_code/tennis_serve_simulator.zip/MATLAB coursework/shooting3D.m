function [thetay,thetaz] = shooting3D(x0,y0,z0,v0,t0,dt,tend,targetx,targetz)

% shooting3D    Guesses input angles give a specific target in 3D space
% 
%     [thetay,thetaz] = shooting3D(v0,y0,x0,z0,t0,dt,targetx,targetz)
%     computes initial angles in the y and z plane thetay and thetaz using 
%     an initial velocity v0, initial position x0 y0 z0, initial time t0, 
%     time step dt and a specified target point in the x and z direction 
%     targetx targetz

% Finds the intial angle ay0
ay0 = atand((targetz-z0)/((targetx)-x0));

% First two guesses of az0
az0(1) = 10;
az0(2) = 80;

% Maximum error for the shooting method
edmax = 0.01;

% Target distance D
targetd = ((((targetx)-x0)^2)+(((targetz)-z0)^2))^0.5;

% Calculating distance D using first guess
D = ivpSolver3D(v0,x0,y0,z0,ay0,az0(1,1),t0,dt);

% Error for first guess
ed(1) = D - targetd;

% Calculating distance D using second guess
D = ivpSolver3D(v0,x0,y0,z0,ay0,az0(1,2),t0,dt);

% Error for second guess
ed(2) = D - targetd;

% While loop keeps looping until error is less than the maximum error
n=2;
while  edmax <= abs(ed(n)) 
    
    % Next guess for initial angle az0
   
    az0(n+1) = az0(n) - ed(n)*((az0(n) - az0(n-1))/(ed(n) - ed(n-1)));
    
    % Next guess for distance D using angle az0
    D(n+1) = ivpSolver3D(v0,x0,y0,z0,ay0,az0(n+1),t0,dt);
    
    % Next error
    ed(n+1) = D(n+1) - targetd;
    
    n = n+1;
    
end


% Final values for thetay and thetaz after the while loop has ended
thetay = ay0;
thetaz = az0(n);

% Plots 3D figure of trajectory
plot3D(x0,y0,z0,v0,t0,dt,tend,thetay,thetaz)
hold off
