function [] = plot2D(x0,y0,v0,t0,dt,theta)

% plot2D   Plots a 2D graph of x against y given input dimensions x0 and
% y0, initial velocity v0, initial time t0, initial angle theta and time
% step dt

% Set initial conditions
t(1) = t0;
d(1) = theta;

% Calculate z
z = [x0;v0*cosd(theta);y0;v0*sind(theta)];

% Continue stepping until the end time is exceeded
n=1;
while z(3,n) >= 0
    % Increment the time vector by one time step
    t(n+1) = t(n) + dt;
    
    % Apply Runge Kutta's method for one time step
    z(:,n+1) = steprungekutta(t(n), z(:,n), dt);

    d(n+1) = atand(z(4,n+1)/z(2,n+1));
   
    n = n+1;
end

% Plot the court
patch([-7 7 7 -7 -7],[-1 -1 0 0 -1],'g')
   
patch([0.01 -0.01 -0.01 0.01 0.01],[1.55 1.55 0 0 1.55],'y')
   
grid on 
 
xlabel('x')
ylabel('y')
xlim([-7 7])
 
% Animated lines for stable and unstable flight specified
h1 = animatedline('Color','r');
h2 = animatedline('Color','b');
    
% Legend plotted 
legend([h1,h2],{'Unstable flight','Stable flight'})

% Animated lines drawn for stable and unstable flight
for i = 1:1:length(z(1,:))
    if t(i) < 0.05
        addpoints(h1,z(1,i),z(3,i));
        drawnow
    else
        addpoints(h2,z(1,i-1),z(3,i-1));
        drawnow
    end
    
end
hold on
 
% Impact point plotted
plot(z(1,end-1),0,'k *')

hold off
