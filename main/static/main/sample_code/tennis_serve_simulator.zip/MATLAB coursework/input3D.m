function [thetay,thetaz,inputvals] = input3D()
% input 3D     Takes input values from user and computes them in the
%              shooting method

% User prompts are input
prompt = {'Initial x value','Initial y value','Initial z value','Initial velocity v','Demand x value','Demand z value'};

% Title set for user input
title = 'Inputs for the trajectory of a shuttlecock';
dims = [1 35];

% Default input selected
definput = {'','','','75','2.1','0'};

% Matrix of input answers
answer = inputdlg(prompt,title,dims,definput);

% Converts input values from cell arrays to regular arrays
inputvals = [];
for i = 1:length(answer)
    inputvals(i) = str2double(answer(i));
end

% Shooting method used for input values
[thetay,thetaz] = shooting3D(inputvals(1),inputvals(2),inputvals(3),inputvals(4),0,0.01,2,inputvals(5),inputvals(6));
