function znext = steprungekutta3D(t,z,dt)
% steprungekutta3D    Compute one step using the Runge-Kutta method
% 
%     znext = steprungekutta(t,z,dt) computes the state vector znext at the next
%     time step t+dt

% Calculate the state derivative from the current state
dz = stateDeriv3D(t, z);

% Computes A,B,C and D for the Runge-Kutta method
A = dt*dz;
B = dt*stateDeriv3D(t + (dt/2), z + A/2);
C = dt*stateDeriv3D(t + (dt/2), z + B/2);
D = dt*stateDeriv3D(t + dt, z + C);



% Calculate the next state vector from the previous one using the
% Runge-Kutta update equation
znext = z + (A + 2*B + 2*C + D)/6;