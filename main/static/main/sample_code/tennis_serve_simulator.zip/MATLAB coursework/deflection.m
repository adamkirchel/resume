function [dphi] = deflection(t,phi,z)

Mc = 0.003; % Mass (kg)
Mb = 0.002;
P = 1.225;
A = 0.000028;
Cd = 0.44;
l = 0.02;

V = (((z(2,end))^2 + (z(4,end))^2)^0.5;

dphi1 = phi(2,end);
dphi2 = -((P*A*Cd*V)/(2*Mb*(1+(Mb/Mc))))*phi(2,end) - ((P*A*Cd*(V^2))/(2*(Mc + Mb)*l))*sin(phi(1,end));

dphi = [dphi1;dphi2];
