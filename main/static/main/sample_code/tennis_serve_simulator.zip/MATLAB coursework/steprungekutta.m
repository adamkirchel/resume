function znext = steprungekutta(t,z,dt)
% steprungekutta    Compute one step using the Runge-Kutta method
% 
%     znext = steprungekutta(t,z,dt) computes the state vector znext at the next
%     time step t+dt

% Calculate the state derivative from the current state
dz = stateDeriv(t, z);

A = dt*dz;
B = dt*stateDeriv(t + (dt/2), z + A/2);
C = dt*stateDeriv(t + (dt/2), z + B/2);
D = dt*stateDeriv(t + dt, z + C);



% Calculate the next state vector from the previous one using the
% Runge-Kutta update equation
znext = z + (A + 2*B + 2*C + D)/6;