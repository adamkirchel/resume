function [D,vend,dialogue] = ivpSolver3D(v0,x0,y0,z0,ay0,az0,t0,dt)
% ivpSolver3D    Solve an initial value problem (IVP) and plot the result
%                in 3D
% 
%     [D] = ivpSolver3D(v0,x0,y0,z0,ay0,az0,t0,dt) computes the IVP 
%     solution using a step size dt, beginning at time t0, initial states 
%     x0,y0,z0 and angles ay0 and az0. The solution is output as a distance 
%     vector D, which is the resultant vector of X and Z.
%     

% Set initial conditions
t(1) = t0;
ay(1) = ay0;
az(1) = az0;

% Values for z matrix specified
z = [x0;v0*cosd(az)*cosd(ay);y0;v0*sind(az);z0;v0*cosd(az)*sind(ay)];

% Continue stepping until the value of y = 0
n=1;
while z(3,n) >= 0
    % Increment the time vector by one time step
    t(n+1) = t(n) + dt;
    
    % Apply Runge Kutta's method for one time step
    z(:,n+1) = steprungekutta3D(t(n), z(:,n), dt);
   
    % Find the next value of ay and az
    ay(n+1) = atand(z(6,n+1)/z(2,n+1));
    az(n+1) = atand((z(4,n+1))/((z(2,n+1))^2 + (z(6,n+1))^2));
    n = n+1;
end

% Outputs dialogue A for vector z
[dialogue] = net(z);

% Find X and Z from z matrix
X = z(1,n)-x0;
Z = z(5,n)-z0;
vend = (((z(2,n))^2 + (z(6,n))^2) + (z(4,n))^2)^0.5;

% Calculates D, the resultant vector of X and Z
D =((X^2)+(Z^2))^0.5;



