function [theta] = shooting(v0,x0,y0,t0,dt,target)

% shooting    Guesses the input angle given a specific target in 2D space
% 
%     [theta] = shooting(v0,x0,y0,t0,dt,target) computes the initial angle
%     in theta using an initial velocity v0, initial position x0 y0,
%     initial time t0, time step dt and a specified target point in the x 
%     direction target.

% Initial angles d0
d0(1) = 10;
d0(2) = 40;

% Maximum allowable error
emax = 0.001;

% Initial guess for x
Zb = ivpSolver(v0,x0,y0,d0(1,1),t0,dt);

% Error for first guess
e(1) = Zb - target;

% Second guess for x
Zb = ivpSolver(v0,x0,y0,d0(1,2),t0,dt);

%Error for second guess
e(2) = Zb - target;
 
% While loop keeps looping until error is less than the maximum error
n=2;
while  emax <= abs(e(n))
    
    % Next guess for initial angle d0
    d0(n+1) = d0(n) - e(n)*((d0(n) - d0(n-1))/(e(n) - e(n-1)));
    
    % Next guess for distance D using angle az0
    Zb(n+1) = ivpSolver(v0,x0,y0,d0(n+1),t0,dt);
    
    % Next error
    e(n+1) = Zb(n+1) - target;
    
    n = n+1;
    
end

% Final values for theta after the while loop has ended
theta = d0(n);

% Plots 2D figure of trajectory
plot2D(x0,y0,v0,t0,dt,theta)