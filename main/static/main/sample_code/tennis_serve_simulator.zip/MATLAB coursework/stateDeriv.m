function [dz] = stateDeriv(t,z)
% Calculates the state derivative for the flight of a shuttlecock
% 
%     dz = stateDeriv(t,z) computes the derivative dz = [dx1; dx2; dy1; dy2];
%     of the state vector z = [x1;x2;y1;y2] where x1 and y1 are
%     displacements in their respective axes, and x2 and y2 are
%     velocities in their respective axes.


M = 0.005; % Mass (kg)
P = 1.225; % Density of air (kg/m^3)
Cd1 = 0.8; % Drag coefficient through unstable flight
Cd2 = 0.6;   % Drag coefficient through stable flight 
A1 = 0.012; % Cross-sectional area in stable flight (m^2)
A2 = 0.009; % Cross-sectional area in unstable flight (m^2)
g = 9.81; % Gravitational acceleration (m/s^2)

% Angle d is calculated
d = atand(z(4,end)/z(2,end));

% Resultant velocity V is calculated
V = ((z(2,end))^2 + (z(4,end))^2)^0.5;

% Decoupled first-order ODEs
if t < 0.05
    dx1 = z(2,end);
    dx2 = -((Cd1*P*((V)^2)*A1)/(2*M))*cosd(d);
    dy1 = z(4,end);
    dy2 = - g - ((Cd1*P*((V)^2)*A1)/(2*M))*sind(d);
else
    dx1 = z(2,end);
    dx2 = -((Cd2*P*((V)^2)*A2)/(2*M))*cosd(d);
    dy1 = z(4,end);
    dy2 = - g -((Cd2*P*(V)^2)*A2)/(2*M)*sind(d);
end

% Results from ODEs combined to form vector dz
dz = [dx1; dx2; dy1; dy2];

    