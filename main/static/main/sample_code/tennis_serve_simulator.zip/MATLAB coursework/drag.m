function [F] = drag(t)

% drag   Calculates the constant used in the equation to find drag
%
%     [F] = drag(t) computes the constant used in the drag equation F
%     for an input time t
%

P = 1.225; % Density of air (kg/m^3)

% Specify boundaries that different coefficients Cd and A are used
if t < 0.05
    Cd = 0.8;
    A = 0.012;
else
    Cd = 0.6;
    A = 0.009;
end

% The constant F is calculated
F = -(P*A*Cd)/2;
    




