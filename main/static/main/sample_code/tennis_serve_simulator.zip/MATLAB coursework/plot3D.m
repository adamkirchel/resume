function [] = plot3D(x0,y0,z0,v0,t0,dt,tend,thetay,thetaz)

% plot3D   Plots a 3D graph in the x,y and z axis given input dimensions
% x0,y0 and z0, initial velocity v0, initial time t0, initial angle thetay
% and thetaz, the time tend and time step dt

% Initial time set
t(1) = t0;

% Initial angles set
ay(1) = thetay;
az(1) = thetaz;

% Values for z matrix specified
z = [x0;v0*cosd(thetaz)*cosd(thetay);y0;v0*sind(thetaz);z0;v0*cosd(thetaz)*sind(thetay)];

% Continue stepping until the value of y = 0
n=1;
while z(3,n) >= 0
    % Increment the time vector by one time step
    t(n+1) = t(n) + dt;
    
    % Apply Runge Kutta's method for one time step
    z(:,n+1) = steprungekutta3D(t(n), z(:,n), dt);
    
    % Find the next value of ay and az
    ay(n+1) = atand(z(6,n+1)/z(2,n+1));
    az(n+1) = atand((z(4,n+1))/((z(2,n+1))^2 + (z(6,n+1))^2));
    n = n+1;
end


       
% Matrices specified for court
q=[-6.7 -6.7 6.7 6.7];
p=[0 0 0 0];
j=[-3.1 3.1 3.1 -3.1];

% Court block plotted on figure
fill3(j,q,p,'b');
hold on
% Matrices specified for net
s=[1.55 1.55 0.81 0.81];
h=[0 0 0 0];
l=[-3.1 3.1 3.1 -3.1];

% Plotting the lines on the court
plot3([-2.53 -2.53],[6.7 -6.7],[0 0],'w')

plot3([2.53 2.53],[6.7 -6.7],[0 0],'w')

plot3([-3.1 3.1],[5.88 5.88],[0 0],'w')

plot3([-3.1 3.1],[-5.88 -5.88],[0 0],'w')

plot3([-3.1 3.1],[1.98 1.98],[0 0],'w')

plot3([-3.1 3.1],[-1.98 -1.98],[0 0],'w')

plot3([0 0],[-1.98 -6.7],[0 0],'w')

plot3([0 0],[1.98 6.7],[0 0],'w')

plot3([3.1 3.1],[0 0],[0 1.55],'k')

plot3([-3.1 -3.1],[0 0],[0 1.55],'k')

% Net block plotted on figure
net = fill3(l,h,s,'y');

alpha(net,.5)

%Initial view set
set(gca,'view',[45 45])

grid on
xlabel('z')
ylabel('x')
zlabel('y')

% Time limits specified
t = [t0:dt:tend];

% Animated lines for stable and unstable flight specified
h1 = animatedline('Color','r');
h2 = animatedline('Color','g');

% Animated lines drawn for stable and unstable flight
for i = 1:1:length(z(1,:))
    if t(i) < 0.05
        addpoints(h1,z(5,i),z(1,i),z(3,i));
        
        drawnow
    else
        addpoints(h2,z(5,i-1),z(1,i-1),z(3,i-1));
        
        drawnow
    end
end

% Impact point plotted
plot3(z(5,end),z(1,end),0,'g *')

% Legend plotted
legend([h1,h2],{'Unstable flight','Stable flight'})

hold off
