function phinext = steprungekuttaphi(z,t,phi,dt)
% steprungekutta3D    Compute one step using the Runge-Kutta method
% 
%     znext = steprungekutta(t,z,dt) computes the state vector znext at the next
%     time step t+dt

% Calculate the state derivative from the current state
dphi = deflection(t,phi,z);

% Computes A,B,C and D for the Runge-Kutta method
A = dt*dphi;
B = dt*deflection(t + (dt/2), phi + A/2,z);
C = dt*deflection(t + (dt/2), phi + B/2,z);
D = dt*deflection(t + dt, phi + C,z);



% Calculate the next state vector from the previous one using the
% Runge-Kutta update equation
phinext = phi + (A + 2*B + 2*C + D)/6;