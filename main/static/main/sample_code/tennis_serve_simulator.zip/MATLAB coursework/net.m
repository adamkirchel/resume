function[X] = net(z)

% Outputs different dialogue depending if the shuttlecock makes it over the
% net.
%
%    [X] = net(z) takes the vector z and computes the value y at min x to 
%    output dialogue A 

% Finds the absolute values of the x values
ab = abs(z(1,:));

% Find index for the minimum value
[~,y] = min(ab);

% Finds the value of y at the minimum value of x
p = z(3,y);

% Displays dialogue based on size of y
    if p < 1.55
    
        X = 'Shuttlecock hit the net';
        
    else
        
        X = 'Shuttlecock passed over the net';
        
    end
    
end