function varargout = GUItrajectory(varargin)
% GUITRAJECTORY MATLAB code for GUItrajectory.fig
%      GUITRAJECTORY, by itself, creates a new GUITRAJECTORY or raises the existing
%      singleton*.
%
%      H = GUITRAJECTORY returns the handle to a new GUITRAJECTORY or the handle to
%      the existing singleton*.
%
%      GUITRAJECTORY('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GUITRAJECTORY.M with the given input arguments.
%
%      GUITRAJECTORY('Property','Value',...) creates a new GUITRAJECTORY or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before GUItrajectory_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to GUItrajectory_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help GUItrajectory

% Last Modified by GUIDE v2.5 03-Dec-2018 13:19:57

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @GUItrajectory_OpeningFcn, ...
                   'gui_OutputFcn',  @GUItrajectory_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before GUItrajectory is made visible.
function GUItrajectory_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to GUItrajectory (see VARARGIN)

% Choose default command line output for GUItrajectory
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes GUItrajectory wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = GUItrajectory_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in plot3D.
function plot3D_Callback(hObject, eventdata, handles)
% hObject    handle to plot3D (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Calls input3D
[thetay,thetaz,inputvals] = input3D()

% ivpSolver3D calculates vend and A
[~,vend,dialogue] = ivpSolver3D(inputvals(4),inputvals(1),inputvals(2),inputvals(3),thetay,thetaz,0,0.01);

% Relates text boxes to calculated values
handles.vendtext.String = num2str(vend);
handles.nettext.String = num2str(dialogue);
drawnow;
pause(5);
cla reset; % Do a complete and total reset of the axes.

% plot3D(handles.plot)

%axes(handles.axes11); % Switch current axes to axes11.
%plot(); % Will plot into axes11.

% --- Executes on button press in plot2D.
function plot2D_Callback(hObject, eventdata, handles)
% hObject    handle to plot2D (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Calls input2D
[theta,inputvals] = input2D()

% ivpSolver3D calculates vend and A
[~,vend,dialogue] = ivpSolver(inputvals(3),inputvals(1),inputvals(2),theta,0,0.01);

% Relates text boxes to calculated values
handles.vendtext.String = num2str(vend);
handles.nettext.String = num2str(dialogue);
drawnow;
pause(5);
cla reset; % Do a complete and total reset of the axes.

% --- Executes during object creation, after setting all properties.
function vendtext_CreateFcn(hObject, eventdata, handles)
% hObject    handle to vendtext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function nettext_CreateFcn(hObject, eventdata, handles)
% hObject    handle to nettext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
