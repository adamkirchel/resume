function[theta,inputvals] = input2D()
% input 2D     Takes input values from user and computes them in the
%              shooting method

% User prompts are input
prompt = {'Initial x value','Initial y value','Initial velocity v','Demand x value'};

% Title set for user input
title = 'Inputs for the trajectory of a shuttlecock';
dims = [1 35];

% Default input selected
definput = {'','','75','2.1'};

% Matrix of input answers
answer = inputdlg(prompt,title,dims,definput);

% Converts input values from cell arrays to regular arrays
inputvals = [];
for i = 1:length(answer)
    inputvals(i) = str2double(answer(i));
end

% Shooting method used for input values
[theta] = shooting(inputvals(3),inputvals(1),inputvals(2),0,0.01,inputvals(4));
