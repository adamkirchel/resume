function [x,vend,dialogue,tend] = ivpSolver(v0,x0,y0,d0,t0,dt)
% ivpSolver    Solve an initial value problem (IVP) and plots the result in
% 2D
% 
%     [x,vend,A,tend] = ivpSolver(v0,x0,y0,d0,t0,dt) computes the IVP solution using a step 
%     size dt, beginning at time t0 and initial state x0 y0 with velocity v0.
%     The solution is output as a distance x, end velocity vend, dialogue A
%     and time tend.

% Set initial conditions
t(1) = t0;
d(1) = d0;
z = [x0;v0*cosd(d);y0;v0*sind(d)];

% Continue stepping until the end time is exceeded
n=1;
while z(3,n) >= 0
    % Increment the time vector by one time step
    t(n+1) = t(n) + dt;
    
    % Apply Runge Kutta's method for one time step
    z(:,n+1) = steprungekutta(t(n), z(:,n), dt);

    d(n+1) = atand(z(4,n+1)/z(2,n+1));
   
    n = n+1;
end

% End time is calculated
tend = t(n);

% Outputs final value for x
x = z(1,n);

% Outputs impact velocity
vend = ((z(2,n)^2)+(z(4,n))^2)^0.5;

% Outputs dialogue if shuttlecock has hit the net
[dialogue] = net(z);

