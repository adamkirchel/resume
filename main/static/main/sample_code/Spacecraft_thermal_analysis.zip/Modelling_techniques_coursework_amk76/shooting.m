function [thickness] = shooting(tmax, nt, nx, method,idealtemp,name)
% Function for guessing the thickness needed to give a maximum value of
% temperature
%
% Input arguments:
%
% tmax        - maximum time
% nt          - number of time steps
% nx          - number of spacial steps
% method      - solution method
% idealtemp   - ideal temperature
%
% Return arguments:
% x      - distance vector
% t      - time vector
% u      - temperature matrix

% Set target temperature
target = idealtemp;

% Guesses for thickness xmax
xmax(1) = 0.1;
xmax(2) = 0.05;


% Maximum allowable error
emax = 1;

% Initial guess for end temperature
[~,~,u] = shuttle1(tmax, nt, xmax(1,1), nx, method,name);
Zb = max(u(:,1));

% Error for first guess
e(1) = Zb - target;

% Second guess for end temperature
[~,~,u] = shuttle1(tmax, nt, xmax(1,2), nx, method,name);
Zb = max(u(:,1));


%Error for second guess
e(2) = Zb - target;
 
% While loop keeps looping until error is less than the maximum error
n=2;
while  emax <= abs(e(n))
    
    % Next guess for thickness xmax
    xmax(n+1) = xmax(n) - e(n)*((xmax(n) - xmax(n-1))/(e(n) - e(n-1)));
    
    % Next guess for end temperature
    [~,~,u] = shuttle1(tmax, nt, xmax(n+1), nx, method,name);
    Zb(n+1) = max(u(:,1));
    % Next error
    e(n+1) = Zb(n+1) - target;
    
    % Next step
    n = n+1;
    
end

% Final values for xmax after the while loop has ended
thickness = xmax(n);

