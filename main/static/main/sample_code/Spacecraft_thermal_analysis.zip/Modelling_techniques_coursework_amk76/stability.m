% Plots stability curves of the four techniques

% User input of tile
name = ['temp' tilechoice()];

% Initialise values
i=0; 
nx = 21; 
thick = 0.05; 
tmax = 4000; 

% Cycle through number of time steps
for nt = 20:20:1000 
    i=i+1; 
    dt(i) = tmax/(nt-1); 
    %disp (['nt = ' num2str(nt) ', dt = ' num2str(dt(i)) ' s']) 
    
    % Calculate values for the forward method
    [~, ~, u] = shuttle1(tmax, nt, thick, nx, 'Forward',name); 
    uf(i) = u(end, 1); 
    
    % Calculate values for the backward method
    [~, ~, u] = shuttle1(tmax, nt, thick, nx, 'Backward',name); 
    ub(i) = u(end, 1); 
    
    % Calculate values for the dufort-frankel method
    [~, ~, u] = shuttle1(tmax, nt, thick, nx, 'Dufort-frankel',name); 
    ud(i) = u(end, 1); 
    
    % Calculate values for the cranknicolson method
    [~, ~, u] = shuttle1(tmax, nt, thick, nx, 'Crank-nicolson',name); 
    uc(i) = u(end, 1);
end 

% Plot stability curves
plot(dt, [uf; ud; ub; uc]) 
legend('Forward','Dufort-frankel','Backwards','Crank-nicolson')

hold on

% Plots upper and lower limits for accuracy
upperlim = 1.001*uc(end);
lowerlim = 0.999*uc(end);

line([0,150],[upperlim,upperlim],'LineStyle','--')
line([0,150],[lowerlim,lowerlim],'LineStyle','--')

% Generates limits and labels
d = ['End temperature value (' char(176) 'C)'];
xlim([0 200]);
ylim([100 200]);
xlabel('Time step (s)')
ylabel(d)