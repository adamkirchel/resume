function [x, t, u] = shuttle()
% Function for modelling temperature in a space shuttle tile
%
% Return arguments:
% x      - distance vector
% t      - time vector
% u      - temperature matrix

% User inputs for parameters
prompts = {'Maximum time (sec)', 'Timestep (sec)','Thickness (m)','Spacial step (m)'};
defaults = {'4000', '29','0.05','0.0035'};

answer = inputdlg(prompts, '2D Tile Model', 1, defaults);

% Converting user inputs into numbers
tmax = str2num(answer{1});
dt   = str2num(answer{2});
xmax = str2num(answer{3});
dx = str2num(answer{4});

% User input of method
method = methodchoice;

% User input of tile
name = ['temp' tilechoice()];

% Produce temp597.mat file
plottemp(name)

% Set tile properties
thermcon = 0.141; % W/(m K)
density  = 351;   % 22 lb/ft^3
specheat = 1259;  % ~0.3 Btu/lb/F at 500F

% Input tempdata and timedata
load temp597.mat

% Initialise parameters.
nt = round(tmax/dt);
t = (0:nt-1) * dt;
nx = round(xmax/dx);
x = (0:nx-1) * dx;
u = zeros(nt, nx);

alpha = thermcon/(density*specheat);
p = alpha * dt / dx^2;

% Initialising vector
ivec = 2:nx-1;

% Set initial conditions to 16C throughout for the first two timesteps.
u([1 2], :) = 16;

% Use interpolation to get temperature R at time t(n+1).
R = interp1(timedata, tempdata, t, 'linear', 'extrap');

% Main timestepping loop.
for n = 2:nt - 1
    
    % RHS boundary condition: outer surface. 
    u(n,nx) = R(n+1);
    
    % Select method.
    switch method
        case 'Forward'
            % Implement Neumann boundary
            u(n+1, 1) = (1 - 2 * p)*u(n, 1) + (2 * p)*u(n,2);
            
            % Cycle through forward method
            u(n+1,ivec) = (1 - 2 * p) * u(n,ivec) + p * (u(n,ivec-1) + u(n,ivec+1));
            
        case 'Dufort-frankel'
            % Implement Neumann boundary
            u(n+1, 1) = ((1 - 2 * p)*u(n-1, 1) + (4 * p)*u(n,2))/(1 + 2*p);
            
            % Cycle through dufort-frankel method
            u(n+1, ivec) = ((1 - 2 * p) * u(n-1,ivec) + 2* p * (u(n,ivec-1) + u(n,ivec+1)))/(1 + 2 * p);
            
        case 'Backward'
            
            % Initial matrix values
            b(1)      = 1 + 2*p;
            c(1)      = -2*p;
            d(1)      = u(n,1);
            
            % Input remaining matrix values
            a(ivec) = -p;
            b(ivec) = 1 + 2*p;
            c(ivec) = -p;
            d(ivec) = u(n, ivec);
            
            % Input final matrix values
            a(nx)     = 0;
            b(nx)     = 1;
            d(nx)     = R(n);
    
            % Use tri-diagonal matrix method to work out vector u
            u(n+1,:) = tdm(a,b,c,d);
            
        case 'Crank-nicolson'
            
            % Initial matrix values
            b(1)      = 1 + p;
            c(1)      = -p;
            d(1)      = (1-p)*u(n,1) + p*u(n,2);
            
            % Input remaining matrix values
            a(ivec) = -p/2;
            b(ivec) = 1 + p;
            c(ivec) = -p/2;
            d(ivec) = (p/2)*u(n,ivec-1) + (1-p)*u(n,ivec) + (p/2)*u(n,ivec + 1);
            
            % Input final matrix values
            a(nx)     = 0;
            b(nx)     = 1;
            d(nx)     = R(n);
            
            % Use tri-diagonal matrix method to work out vector u
            u(n+1,:) = tdm(a,b,c,d);
            
        otherwise
            error (['Undefined method: ' method])
            return
    end
end

% Plots the temperature distribution 
waterfall(x,t,u)


% Limits and axis labels
zlim([0 1000])
view(140,30)
xlabel('\itx\rm - m')
ylabel('\itt\rm - s')
zlabel('\itu\rm - deg C')



    