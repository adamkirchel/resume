
% Plots stability curves of the four techniques for given spatial steps dx

% User input of tile
name = ['temp' tilechoice()];

% Initialise values
i=0; 
nt = 1000; 
thick = 0.05; 
tmax = 4000; 

% Cycle through number of time steps
for nx = 5:5:300 
    i=i+1; 
    dx(i) = thick/(nx-1); 
    disp (['nx = ' num2str(nx) ', dx = ' num2str(dx(i)) ' m']) 
    
    % Calculate values for the Forward method
    [~, ~, u] = shuttle1(tmax, nt, thick, nx, 'Forward',name); 
    uf(i) = u(end, 1); 
    
    % Calculate values for the Backward method
    [~, ~, u] = shuttle1(tmax, nt, thick, nx, 'Backward',name); 
    ub(i) = u(end, 1); 
    
    % Calculate values for the Dufort-frankel method
    [~, ~, u] = shuttle1(tmax, nt, thick, nx, 'Dufort-frankel',name); 
    ud(i) = u(end, 1); 
    
    % Calculate values for the Crank-Nicolson method
    [~, ~, u] = shuttle1(tmax, nt, thick, nx, 'Crank-nicolson',name); 
    uc(i) = u(end, 1);
end 

% Plot stability curves
plot(dx, [uf; ud; ub; uc]) 
legend('Forward','Dufort-frankel','Backwards','Crank-nicolson')

hold on

%Plot upper and lower accuracy limits
upperlim = 1.001*uc(end);
lowerlim = 0.999*uc(end);

line([0,0.013],[upperlim,upperlim],'LineStyle','--')
line([0,0.013],[lowerlim,lowerlim],'LineStyle','--')


f = ['End temperature value(' char(176) 'C)'];

% Labels the axis
xlim([0 0.01]);
ylim([160 170]);
xlabel('Spatial step (m)')
ylabel(f)