function [thickness] = plotinner()
% Function for plotting the variation of the temperature of the inner surface against time
%
% Output arguments:
%
% thickness    - ideal thickness to give the ideal maximum temperature


%Dialog box for max. time and timestep
prompts = {'Maximum time (sec)', 'Timestep (sec)','Thickness (m)','Spacial step (m)',['Ideal max temperature(' char(176) 'C)']};
defaults = {'4000', '29','0.05','0.0035','200'};

answer = inputdlg(prompts, '2D Tile Model', 1, defaults);

% Converting user inputs into numbers
tmax = str2num(answer{1});
dt   = str2num(answer{2});
xmax = str2num(answer{3});
dx = str2num(answer{4});
idealtemp = str2num(answer{5});

% User input of method
method = methodchoice;

% User input of tile
name = ['temp' tilechoice()];

% Finding the nummber of time steps and spacial steps
nt = round(tmax/dt);
nx = round(xmax/dx);

% Finding the u and t values
[~, t, u] = shuttle1(tmax, nt, xmax, nx, method,name);

% Plots inner surface temperature against time
plot(t,u(:,1))

% Generates ideal thickness using the shooting method
[thickness] = shooting(tmax, nt, nx, method, idealtemp,name);

% Labels the axis
s = ['Temperature (' char(176) 'C)'];
xlabel('Time (s)')
ylabel(s)