function [modey,finalx,modex,finaly,img] = black()
% Function for automatically finding axis from NASA data files
% 
% Return arguments:
% modey      - initial x axis indices
% finalx     - last x axis indices
% modex      - initial y axis indices
% finaly     - last y axis indices
% img        - Image matrices

% Read image file
name = 'temp597';
img=imread([name '.JPG']);
s = size(img);
% Cycle through pixels of the image along the x axis
for n = 1:s(2)
    
    % Locate pixels which are black
    X = img(:,n,1)<110 & img(:,n,2) < 120 & img(:,n,3) < 120;
    
    % Find indices of black pixel
    I = find(X == 1);
   
    % Find length of indices
    r = length(I);
    
    % Find pixel indices that are next to each other
    if r > 0
       for m = 1:r
            if abs(img(I(m),n,1) - img(I(m),n-1,1)) < 30
                
                b(n,:) = [n I(m)];
            end
       end
    else
        b(n,:) = [n 0];
            
       
    end
        
end 

% Find y axis pixel value
 a = b(:,2);
 modey = mode(a);

 my = zeros(length(b),1);
 
 lastx = find(b(:,2) == modey);

 % Find final x axis pixel value
 finalx = lastx(end);
 
 % Cycle through pixels of the image along the y axis
 for n = 1:s(1)
    
    % Locate pixels which are black
    X = img(n,:,1)<110 & img(n,:,2) < 120 & img(n,:,3) < 120;
    
    % Find indices of black pixel
    I = find(X == 1);
   
    % Find length of indices
    r = length(I);
    
    % Find pixel indices that are next to each other
    if r > 0
    
        for m = 1:r
    
            if abs(img(n,I(m),1) - img(n-1,I(m),1)) < 20
        
                e(n,:) = [n I(m)];
            
            end
        
        end
    else
        e(n,:) = [n 0];
    end
        
 end  

 % Find x axis pixel value
 a = e(:,2);
 modex = mode(a);

 mx = zeros(length(e),1);
 
lasty = find(e(:,2) == modex);
 
% Find final y axis pixel value
 finaly = lasty(1);