function [x, t, u] = shuttle2D()

% Function for modelling temperature in a space shuttle tile in 2D.
% Can model a crack through the thickness of the tile at a random length.
% Return arguments:
% x      - distance vector
% t      - time vector
% u      - temperature matrix

% User input for initial parameters
prompts = {'Maximum time (sec)', 'Timestep (sec)','Thickness (m)','Spacial step in x (m)','Length (m)','Spatial step in y (m)'};
defaults = {'4000', '3','0.05','0.0025','0.05','0.0025'};

answer = inputdlg(prompts, '2D Tile Model', 1, defaults);

% Converting the inputs to number outputs
tmax = str2num(answer{1});
dt   = str2num(answer{2});
xmax = str2num(answer{3});
dx = str2num(answer{4});
ymax = str2num(answer{5});
dy = str2num(answer{6});

% User input for the choice of method
method = methodchoice;

% User input of tile
name = ['temp' tilechoice()];

% Produce temp597.mat file
plottemp(name)

% Set tile properties
thermcon = 0.141; % W/(m K)
density  = 351;   % 22 lb/ft^3
specheat = 1259;  % ~0.3 Btu/lb/F at 500F

% Input tempdata and timedata
load temp597.mat

% Initialise parameters
nt = round(tmax/dt);
t = (0:nt-1) * dt;
nx = round(xmax/dx);
x = (0:nx-1) * dx;
ny = round(ymax/dy);
y = (0:ny-1) * dy;
u = zeros(ny, nx, nt);

ivecx = 2:nx-1;
ivecy = 2:ny-1;

alpha = thermcon/(density*specheat);
p = alpha * dt / dx^2;

% Set initial conditions to 16C throughout for the first two timesteps.
u( :, :, 1) = 16;

% Handle for animated plot
h = surf(x, y, u(:,:,1));

% Labels axis
s = ['Temperature (' char(176) 'C)'];
xlabel('Thickness (m)')
ylabel('Length (m)')
zlabel(s)

zlim([0 2000])

% Use interpolation to get temperature R at time t(n+1).
R = interp1(timedata, tempdata, t, 'linear', 'extrap');

% Initialise i vectors
i = 1:nx-1;
im = [2 1:nx-2];
ip = [2:nx];

% Find a random point along the length of the tile
t = randi([1 ny-1],1,1);

% Isolate vector of crack and matrices of tile
for r = 1:ny
    if r < t || r > t+1
        a(r) = r;
        
    else
        b(r) = r;
    end
        
end

% Final crack vector
k = b(b~=0);

% Final tile vector
j = a(a~=0);

% Initialise tile vector without crack
jj = 1:ny;
jm = [2 1:ny-1];
jp = [2:ny ny-1];

for n = 1:nt-1
    
    % RHS boundary condition: outer surface.
    u(:,nx,n+1) = R(n+1);
    
    
    
    % Select method.
    switch method
        case 'Forward'
            
            % Cycle through forward method assuming no crack 
            u(jj,i,n+1) = (1 - 4 * p) * u(jj,i,n)...
                + p * (u(jj,im,n) + u(jj,ip,n) + u(jm,i,n) + u(jp,i,n));
            
            % Update graph with data for the crack values
            u(k,:,n+1) = R(n+1);
            
            % Update graph with new values
            set(h,'ZData', u(:, :, n+1));
            
            % and refresh it on screen
            drawnow
            
        otherwise
            error (['Undefined method: ' method])
            return
    end
    
    
    
end




   










