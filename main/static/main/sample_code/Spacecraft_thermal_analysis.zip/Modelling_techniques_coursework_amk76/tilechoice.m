function choice = tilechoice
% Function for creating a dialog box to choose a method
%
% Output arguments:
%
% choice    - choice of method

% Forms dialog box
    d = dialog('Position',[300 300 250 150],'Name','Select One');
    % Creates text in the dialog box
    txt = uicontrol('Parent',d,...
           'Style','text',...
           'Position',[20 80 210 40],...
           'String','Select a tile');
    
    % Creates pop-up box
    popup = uicontrol('Parent',d,...
           'Style','popup',...
           'Position',[75 70 100 25],...
           'String',{'468';'480';'502';'590';'597';'711';'730';'850'},...
           'Callback',@popup_callback);
    
    % Creates push button
    btn = uicontrol('Parent',d,...
           'Position',[89 20 70 25],...
           'String','OK',...
           'Callback','delete(gcf)');
    
    % Initial choice
    choice = '597';
       
    % Wait for d to close before running to completion
    uiwait(d);
   
    % Varies the output of the function based upon the choice of method
   function popup_callback(popup,event)
          idx = popup.Value;
          popup_items = popup.String;
         
          choice = char(popup_items(idx,:));
       end
      
end