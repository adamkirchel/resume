function [] = plottemp(name)

% Script to automatically scan image



img=imread([name '.jpg']);

%figure (4);
%image(img);
%hold on
% You can adapt the following code to enter data interactively or automatically.

[timedata,tempdata] = red();   
    
%hold off

% sort data and remove duplicate points.
[timedata, index] = unique(timedata);
tempdata = tempdata(index);

%save data to .mat file with same name as image file
save(name, 'timedata', 'tempdata')

