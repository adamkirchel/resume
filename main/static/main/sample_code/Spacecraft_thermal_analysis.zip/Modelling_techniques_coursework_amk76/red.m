function [timedata,tempdata] = red()
% Function for extracting data from the NASA image files.
% 
% Return arguments:
% timedata      - time vector
% tempdata      - temperature vector

% Call black() which locates x and y axis in image
[modey,finalx,modex,finaly,img] = black();
s = size(img);
% Cycle through pixels of the image along the x axis
for n = modex : s(2)

    % Selecting red values
    X = img(:,n,1)>130 & img(:,n,2) < 100 & img(:,n,3) < 100;
    
    %Finding indices of red pixel
    I = find(X == 1);
 
    % Find the mean value of the red data point
    meanred = mean(I);
    
    % Invert the data
    flipped = modey - meanred;
    
    % Calculate time in number of strips
    time = n - modex;
    
    % Convert image values to actual x and y values
    yvalue = flipped*(2000/(modey-finaly));
    ypoint = ((yvalue - 32)*5)/9;
    xpoint = time*(2000/(finalx-modex));
    
    % Eliminate anomalies 
    if xpoint > 300
        if isnan(ypoint) == 1
            continue
        else
            m(n,:) = [xpoint ypoint];
        end
    end
  
end

% Create time and temperature data
timedata = m(:,1);
tempdata = m(:,2);