import pandas as pd
import numpy as np
from matplotlib import pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn import utils
from sklearn import preprocessing

#Create your df here:
df = pd.read_csv(r'C:\Users\adsk1\python_3\work\Dating_app\profiles.csv')

print(df.job.head())

print(df.job.value_counts())

print(df.orientation.value_counts())

print(df.columns)

bar_labels = ['body_type','diet','drinks','drugs','education','ethnicity','job','offspring','orientation','pets','religion','sex','sign','smokes','status']
hist_labels = ['age','height','income']

lbl = ['Age','Body Type','Height','Profession']



objects_body_type = df.body_type.unique()
x_pos_body_type = np.arange(len(objects_body_type)-1)
counter_body_type = df.groupby('body_type').size()

body_type_freq = []

for i in range(len(counter_body_type)):
    
    body_type_freq.append(counter_body_type[i])
    

objects_job = df.job.unique()
x_pos_job = np.arange(len(objects_job)-1)
counter_job = df.groupby('job').size()

job_freq = []

for i in range(len(counter_job)):
    
    job_freq.append(counter_job[i])
    
objects_diet = df.diet.unique()
x_pos_diet = np.arange(len(objects_diet)-1)
counter_diet = df.groupby('diet').size()

diet_freq = []

for i in range(len(counter_diet)):
    
    diet_freq.append(counter_diet[i])
    
objects_drinks = df.drinks.unique()
x_pos_drinks = np.arange(len(objects_drinks)-1)
counter_drinks = df.groupby('drinks').size()

drinks_freq = []

for i in range(len(counter_drinks)):
    
    drinks_freq.append(counter_drinks[i])
    
objects_drugs = df.drugs.unique()
x_pos_drugs = np.arange(len(objects_drugs)-1)
counter_drugs = df.groupby('drugs').size()

drugs_freq = []

for i in range(len(counter_drugs)):
    
    drugs_freq.append(counter_drugs[i])
    
objects_education = df.education.unique()
x_pos_education = np.arange(len(objects_education)-1)
counter_education = df.groupby('education').size()

education_freq = []

for i in range(len(counter_education)):
    
    education_freq.append(counter_education[i])
    

fig, axs = plt.subplots(2,2)
axs[0,0].hist(df.age, bins=20)
axs[0,0].tick_params(axis="x", labelsize=8)
axs[0,0].set_title('Variation of age')
axs[0,0].set_xlim(18,75)
axs[0,1].barh(x_pos_body_type,body_type_freq)
axs[0,1].set_title('Variation of body type')
axs[0,1].set_yticks(range(len(objects_body_type)))
axs[0,1].set_yticklabels(objects_body_type,fontsize=3)
axs[1,0].hist(df.height, bins=20)
axs[1,0].set_title('Variation of height')
axs[1,0].set_xlim(50,90)
axs[1,1].barh(x_pos_job,job_freq)
axs[1,1].set_title('Variation of profession')
axs[1,1].set_yticks(range(len(objects_job)))
axs[1,1].set_yticklabels(objects_job,fontsize=3)

i = 0

for ax in axs.flat:

    ax.set(xlabel='Frequency',ylabel=lbl[i])
    
    i += 1
    
plt.tight_layout()

fig, axs = plt.subplots(2,2)
axs[0,0].barh(x_pos_diet,diet_freq)
axs[0,0].set_title('Variation of diet')
axs[0,0].set_yticks(range(len(objects_diet)))
axs[0,0].set_yticklabels(objects_diet,fontsize=3)

axs[0,1].barh(x_pos_drinks,drinks_freq)
axs[0,1].set_title('Variation of drinks')
axs[0,1].set_yticks(range(len(objects_drinks)))
axs[0,1].set_yticklabels(objects_drinks,fontsize=3)

axs[1,1].barh(x_pos_drugs,drugs_freq)
axs[1,1].set_title('Variation of drugs')
axs[1,1].set_yticks(range(len(objects_drugs)))
axs[1,1].set_yticklabels(objects_drugs,fontsize=3)

axs[1,0].barh(x_pos_education,education_freq)
axs[1,0].set_title('Variation of education')
axs[1,0].set_yticks(range(len(objects_education)))
axs[1,0].set_yticklabels(objects_education,fontsize=3)

lbl = ['Diet','Drinking habit','Drug Habit','Education']

i = 0

for ax in axs.flat:

    ax.set(ylabel='Frequency',xlabel=lbl[i])
    
    i += 1

plt.tight_layout()



plt.show()


def plot_feature(feature):
        
    if feature in bar_labels:
    
        objects = df[feature].unique()
        objects = [object for object in objects if str(object) != 'nan']
        objects.sort()
        x_pos = np.arange(len(objects))
        counter = df.groupby(feature).size()

        freq = []
    
        print(objects)
        print(counter)

        for i in range(len(counter)):
        
        
            freq.append(counter[i])
        
        

    
        plt.barh(x_pos,freq)
        plt.title('Variation in %s' %feature)
        plt.yticks(range(len(objects)),objects)
       # plt.yticklabels(objects_diet,fontsize=3)
        plt.ylabel(feature)
        plt.xlabel('Frequency')
        plt.show()
        
    else:
    
        plt.hist(df[feature], bins=20)
        plt.tick_params(axis="x", labelsize=8)
        plt.title('Variation of %s' %feature)
        plt.xlim(df[feature].min(),df[feature].max())
        plt.xlabel(feature)
        plt.ylabel('Frequency')
        plt.show()
        
        
#for feature in bar_labels:

    #plot_feature(feature)
    
#for feature in hist_labels:

    #plot_feature(feature)
    

        
    
def linear_regression(independent_feature,dependent_feature):

    #Initialise data
    dependent_data = df[dependent_feature]
    independent_data = df[independent_feature]
    
    #Split into training and test data
    
    independent_train, independent_test, dependent_train, dependent_test = train_test_split(independent_data,dependent_data,train_size = 0.8)
 
    #Visualise the data
    plt.scatter(dependent_data,independent_data)
    plt.xlabel(dependent_feature)
    plt.ylabel(independent_feature)
    plt.title('%s vs %s' %(independent_feature,dependent_feature))
    plt.show()
    
    #Train the model on the training data
    model = LinearRegression()
    
    #Reshape the data
    dependent_train = dependent_train.values.reshape(-1,1)
    independent_train = independent_train.values.reshape(-1,1)
    dependent_test = dependent_test.values.reshape(-1,1)
    independent_test = independent_test.values.reshape(-1,1)
    
    model.fit(independent_train,dependent_train)
    
    #Predict test values
    model.predict(independent_test)
    
    #Assess coeff of determination
    accuracy = model.score(independent_test,dependent_test)
    
    return accuracy
    
def multi_linear_regression(independent_features,dependent_feature):

    #Initialise data
    dependent_data = df[dependent_feature]
    independent_data = df[independent_features]

    #Remove NaN
    dependent_data.fillna({dependent_feature:1},inplace=True)
    
    for i in range(len(independent_features)):
        independent_data.fillna({independent_features[i]:1},inplace = True)
        
        
    print(independent_data.isna().any())

    #Initialise data
    dependent_data = np.asarray(dependent_data)
    independent_data = np.asarray(independent_data)
    
    #Split into training and test data
    independent_train, independent_test, dependent_train, dependent_test  = train_test_split(independent_data,dependent_data,train_size = 0.8)
    
    #Train the model on the training data
    model = LinearRegression() 
    
    #Reshape the data
    #dependent_train = dependent_train.reshape(-1,1)
    #independent_train = independent_train.reshape(-1,1)
    #dependent_test = dependent_test.reshape(-1,1)
    #independent_test = independent_test.reshape(-1,1)
    
    model.fit(independent_train,dependent_train)
    
    #Predict test values
    model.predict(independent_test)
    
    #Assess coeff of determination
    accuracy = model.score(independent_test,dependent_test)
    
    return accuracy
 



def k_nearest(independent_features,dependent_feature,k):

    # Visualise data
   # plt.scatter(df[dependent_feature],df[independent_features][0],df[independent_features[1]])
    #plt.xlabel(dependent_feature)
    #plt.ylabel(independent_feature[0] + independent_features[1])
    #plt.show()
    
    dependent_objects = df[dependent_feature].unique()
    
    dependent_mapping = dict()
    
    for n in range(len(dependent_objects)):
        dependent_mapping.update({dependent_objects[n]:n})
        
        
    df["dependent_code"] = df.sex.map(dependent_mapping)
    
    #independent_objects = df[independent_feature].unique()
    
    #independent_mapping = dict()
    
    #for n in range(len(dependent_objects)):
       # independent_mapping.update({dependent_objects[n]:n})
        
        
    #df["independent_code"] = df.sex.map(independent_mapping)
    
    
    #print(df.sex.value_counts())
    
    #Initialise data
    dependent_data = df["dependent_code"]
    independent_data = df[independent_features]
    
    dependent_data.fillna(0,inplace = True)
    
    
    dependent_normalised = []
    
    minimum_dependent = min(dependent_data)
    maximum_dependent = max(dependent_data)
    #print(minimum_dependent)
    #print(maximum_dependent)
    
    for x in dependent_data:
    
        dependent_normalised.append((x - minimum_dependent)/(maximum_dependent - minimum_dependent))
        
    #print(dependent_data.info)
        
    #independent_normalised = []
    
    independent_df = pd.DataFrame()
        
    for i in range(len(independent_features)):
        
        minimum_independent = min(df[independent_features[i]])
        #print(minimum_independent)
        maximum_independent = max(df[independent_features[i]])
        #print(maximum_independent)
        
        
        independent_df[independent_features[i] + '_normalised'] = df[independent_features[i]].apply(lambda x: (x - minimum_independent)/(maximum_independent - minimum_independent))
        #print(independent_features[i])
        #print(independent_df.info)
        
        
    
    
    for i in range(len(independent_features)):
        independent_df.fillna({independent_features[i] + '_normalised':0},inplace = True)
        
    independent_normalised = np.array(independent_df)
    #print(independent_df.isna().any())
    #print(dependent_data.isna().any())
    
        #for x in range(len(df[independent_features[i]])):
    
            #new.append(((x - minimum_independent)/(maximum_independent - minimum_independent)))
            
        #independent_normalised.append(new)
    #print(independent_df.info)
    
    #ddependent_data = [(x - min(dependent_data))/(max(dependent_data) - min(dependent_data)) for x in dependent_data]
    #print(data)
    
    #independent_data = [(x - min(independent_data))/(max(independent_data) - min(independent_data)) for x in independent_data]
    
    #print(max(dependent_normalised))
    #print(min(independent_normalised))
    
    #dependent_normalised = np.asarray(dependent_normalised)
    #independent_normalised = np.asarray(independent_normalised)
    
    #Split into training and test data
    
    independent_train, independent_test, dependent_train, dependent_test = train_test_split(independent_normalised,dependent_normalised,train_size = 0.8)
    
    #Reshape the data
    #dependent_train = dependent_train.values.reshape(-1,1)
    #independent_train = independent_train.values.reshape(-1,1)
    #dependent_test = dependent_test.values.reshape(-1,1)
    #independent_test = independent_test.values.reshape(-1,1)
    
    classifier = KNeighborsClassifier(n_neighbors = k)
    
    classifier.fit(independent_train,dependent_train)
    
    
    
    accuracy = classifier.score(independent_test,dependent_test)
    
    return accuracy
    
def k_nearest_optimised(independent_features,dependent_feature):

    accuracy = []
    
    for k in range(1,10):
    
        accuracy.append(k_nearest(independent_features,dependent_feature,k))
        
    plt.plot(range(1,10),accuracy)
    plt.xlabel('k')
    plt.ylabel('Accuracy')
    plt.show()
    
    max_index = accuracy.index(max(accuracy))
    
    k_optimal = max_index + 1
    
    return k_optimal
    
def k_nearest_predict(independent_features,dependent_feature):
    
    k_optimal = k_nearest_optimised(independent_features,dependent_feature)
    
    
    dependent_objects = df[dependent_feature].unique()
    
    dependent_mapping = dict()
    
    for n in range(len(dependent_objects)):
        dependent_mapping.update({dependent_objects[n]:n})
        
        
    df["dependent_code"] = df[dependent_feature].map(dependent_mapping)
    
    
    #Initialise data
    dependent_data = df["dependent_code"]
    independent_data = df[independent_features]
    
    dependent_data.fillna(0,inplace = True)
    
    
    dependent_normalised = []
    
    minimum_dependent = min(dependent_data)
    maximum_dependent = max(dependent_data)
    #print(minimum_dependent)
    #print(maximum_dependent)
    
    for x in dependent_data:
    
        dependent_normalised.append((x - minimum_dependent)/(maximum_dependent - minimum_dependent))
        
    #print(dependent_data.info)
        
    #independent_normalised = []
    
    income = input('What is your income in $? ')
    height = input('What is your height in inches? ')
    
    income = (int(income) - min(df[independent_features[0]]))/(max(df[independent_features[0]]) - min(df[independent_features[0]]))
    
    height = (int(height) - min(df[independent_features[1]]))/(max(df[independent_features[1]]) - min(df[independent_features[1]]))
    
    independent_df = pd.DataFrame()
        
    for i in range(len(independent_features)):
        
        minimum_independent = min(df[independent_features[i]])
        #print(minimum_independent)
        maximum_independent = max(df[independent_features[i]])
        #print(maximum_independent)
        
        
        independent_df[independent_features[i] + '_normalised'] = df[independent_features[i]].apply(lambda x: (x - minimum_independent)/(maximum_independent - minimum_independent))
        #print(independent_features[i])
        #print(independent_df.info)
        
        
    
    
    for i in range(len(independent_features)):
        independent_df.fillna({independent_features[i] + '_normalised':0},inplace = True)
        
    independent_normalised = np.array(independent_df)

    
    #Split into training and test data
    
    independent_train, independent_test, dependent_train, dependent_test = train_test_split(independent_normalised,dependent_normalised,train_size = 0.8)
    
    #Reshape the data
    #dependent_train = dependent_train.values.reshape(-1,1)
    #independent_train = independent_train.values.reshape(-1,1)
    #dependent_test = dependent_test.values.reshape(-1,1)
    #independent_test = independent_test.values.reshape(-1,1)
    
    classifier = KNeighborsClassifier(n_neighbors = k_optimal)
    
    classifier.fit(independent_train,dependent_train)
    
    predictions = classifier.predict([[income,height]])
    
    return predictions
    
    
    
#print(linear_regression('age','income'))
#print(multi_linear_regression(['age','height'],'income'))

#print(k_nearest(['income','height'],'sex',3))
        
#print(k_nearest_optimised(['income','height'],'sex'))

#print(k_nearest_predict(['income','height'],'sex'))

#Only works for dependent already being categorical and independent being continuous, should try and binarise all data first
class k_nearest(object):

    def __init__(self,independent_features,dependent_feature):
    
        self.independent_features = independent_features
        self.dependent_feature = dependent_feature
        
        self.dependent_objects = df[dependent_feature].unique()
       
        self.dependent_mapping = dict()
    
        for n in range(len(self.dependent_objects)):
            self.dependent_mapping.update({self.dependent_objects[n]:n})
        
        #Binarise labels
        df["dependent_code"] = df[dependent_feature].map(self.dependent_mapping)
    
    
        #Initialise data
        self.dependent_df = df["dependent_code"]
        self.independent_df = df[independent_features]
        
        #Remove NaN
        self.dependent_df.fillna(0,inplace = True)
        
        
        
        
    def normalise(self):
    
        dependent_normalised = []
    
        minimum_dependent = min(self.dependent_df)
        maximum_dependent = max(self.dependent_df)
    
    
        for x in self.dependent_df:
    
            dependent_normalised.append((x - minimum_dependent)/(maximum_dependent - minimum_dependent))
        
    
        independent_df = pd.DataFrame()
        
        for i in range(len(self.independent_features)):
        
            minimum_independent = min(df[self.independent_features[i]])
            
            maximum_independent = max(df[self.independent_features[i]])
      
            independent_df[self.independent_features[i] + '_normalised'] = df[self.independent_features[i]].apply(lambda x: (x - minimum_independent)/(maximum_independent - minimum_independent))
    
        
            independent_df.fillna({self.independent_features[i] + '_normalised':0},inplace = True)
        
        independent_normalised = np.array(independent_df)
        
        return dependent_normalised, independent_normalised
        
        
    def training(self,k):
    
        dependent_normalised,independent_normalised = self.normalise()
    
        independent_train, independent_test, dependent_train, dependent_test = train_test_split(independent_normalised,dependent_normalised,train_size = 0.8)
    
        
        classifier = KNeighborsClassifier(n_neighbors = k)
        
        #lab_enc = preprocessing.LabelEncoder()
        #dependent_train_encoded = lab_enc.fit_transform(dependent_train)
        #print(dependent_train_encoded)
        #print(utils.multiclass.type_of_target(dependent_train))
        #print(utils.multiclass.type_of_target(np.array(dependent_train).astype('int')))
        #print(utils.multiclass.type_of_target(dependent_train_encoded))
        
        print(dependent_train_encoded[1:10])
    
        classifier.fit(independent_train,dependent_train_encoded)
    
        accuracy = classifier.score(independent_test,dependent_test)
    
        return accuracy, classifier
        
    
    
    def k_optimal(self):
    
        accuracy = []
    
        for k in range(1,10):
    
            accuracy.append(self.training(k)[0])
        
        plt.plot(range(1,10),accuracy)
        plt.xlabel('k')
        plt.ylabel('Accuracy')
        plt.show()
        
        max_index = accuracy.index(max(accuracy))
        
        k_optimal = max_index + 1
    
        return k_optimal
    
    
    
    def predict(self):
    
        income = input('What is your income in $? ')
        height = input('What is your height in inches? ')
        
        income = (int(income) - min(df[self.independent_features[0]]))/(max(df[self.independent_features[0]]) - min(df[self.independent_features[0]]))
    
        height = (int(height) - min(df[self.independent_features[1]]))/(max(df[self.independent_features[1]]) - min(df[self.independent_features[1]]))
    
        k_chosen = self.k_optimal()
        
        accuracy, classifier = self.training(k_chosen)
        
        prediction = classifier.predict([[income,height]])
        
        for key, value in self.dependent_mapping.items():
            if value == prediction:
                return key
              
        
    def plot():
        
        pass
    
    
print(k_nearest(['income','height'],'drugs').predict())