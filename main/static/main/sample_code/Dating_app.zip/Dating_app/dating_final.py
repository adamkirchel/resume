import pandas as pd
import numpy as np
from matplotlib import pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn import utils
from sklearn import preprocessing
from sklearn.linear_model import LogisticRegression
from sklearn import svm
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, recall_score, precision_score, f1_score
from sklearn.cluster import KMeans
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.linear_model import Perceptron
from sklearn.neural_network import MLPRegressor

#Create your df here:
df = pd.read_csv(r'C:\Users\adsk1\python_3\work\Dating_app\profiles.csv')


# Initialise parent class
class dating_app(object):
    
    # Initialise normalised dataframes for data and labels
    def __init__(self,data_features,label_feature):
        
        # List of quantative features
        self.binarized_list = ['body_type', 'diet', 'drinks', 'drugs', 'education', 'ethnicity', 'job',
       'last_online', 'location', 'offspring', 'orientation', 'pets',
       'religion', 'sex', 'sign', 'smokes', 'speaks', 'status']
       
        # Initialise selected data and label features
        self.data_features = data_features
        self.label_feature = label_feature
        
        # Initialise quantative dataframe for data 
        self.data_binarized_df = pd.DataFrame()
       
        # Initialise unique feature mapping dictionary 
        self.data_binarized_mapping = dict()
        
        # Loop through features to convert str to int in dataframe
        for feature in data_features:
        
            #print(feature)
            
            # Only converts if feature can be quantified
            if feature in self.binarized_list:
                
                # Find unique instances within the feature
                feature_objects = df[feature].unique()
            
                #print(feature_objects)
                
                # Loops through unique instances
                for n in range(len(feature_objects)):
                    
                    # Updates dictionary with a number reflecting the feature
                    self.data_binarized_mapping.update({feature_objects[n]:n})
                    
                # Maps dictionary onto dataframe
                self.data_binarized_df[feature] = df[feature].map(self.data_binarized_mapping)
                
                #print(self.data_binarized_df)
            
            # If data is catagorical            
            else:
            
                self.data_binarized_df[feature] = df[feature]
         
       
        # Initialise quantative dataframe for labels
        self.label_binarized_df = pd.DataFrame()
        
        # Initialise unique feature mapping dictionary
        self.label_binarized_mapping = dict()         
        
        
               
         # Loop through features to convert str to int in dataframe
        if label_feature in self.binarized_list:
            
            self.feature_objects = df[label_feature].unique()
            
            #print(self.feature_objects)
    
            for n in range(len(self.feature_objects)):
    
                self.label_binarized_mapping.update({self.feature_objects[n]:n})
        
                self.label_binarized_df = df[label_feature].map(self.label_binarized_mapping)   
                
            #print(self.label_binarized_df)
                                
    
        # New normailsed dataframe (can not be normailsed for labels)
        self.labels_normalised = self.label_binarized_df
    
        #self.labels_normalised = self.label_binarized_df.apply(lambda x: (x - minimum_dependent)/(maximum_dependent - minimum_dependent))
        
        # Replace NaN with a specified value
        self.labels_normalised.fillna({label_feature:0},inplace=True)
        
        # Initialise normalised dataframe for data
        self.data_normalised = pd.DataFrame()
        
        
        
        # Loop through data features normailsing data
        for i in range(len(data_features)):
        
            if data_features[i] in self.binarized_list:
               
                # Use the minimum and maximum of the dataset to produce a normalised list
                minimum_independent = min(self.data_binarized_df[data_features[i]])
                
                maximum_independent = max(self.data_binarized_df[data_features[i]])
                
            else:
            
                #print(df[data_features[i]])
                
                # Use the minimum and maximum of the dataset to produce a normalised list
                minimum_independent = min(df[data_features[i]])
                
                maximum_independent = max(df[data_features[i]])
            
            
            self.data_normalised[data_features[i]] = self.data_binarized_df[data_features[i]].apply(lambda x: (x - minimum_independent)/(maximum_independent - minimum_independent))
        
            # Replace NaN with a specified int
            self.data_normalised.fillna({data_features[i]:0},inplace = True)
                
            
                
        
        # Initialise train and test sets        
        self.independent_train, self.independent_test, self.dependent_train, self.dependent_test = train_test_split(self.data_normalised,self.labels_normalised,train_size = 0.8)
      
        
    def plot_single(self,x):
    
        bar_labels = ['body_type','diet','drinks','drugs','education','ethnicity','job','offspring','orientation','pets','religion','sex','sign','smokes','status']
        hist_labels = ['age','height','income']
    
        if x in bar_labels:
        
            objects = df[x].unique()
            objects = sorted(objects)
            x_pos = np.arange(len(objects))
            counter = df.groupby(x).size()
            counter.sort_values()
            print(counter)

            freq = []

            for i in range(len(counter)):
                
                freq.append(counter[i])
            
            plt.barh(x_pos,counter)
            plt.yticks(range(len(objects)),objects)
            #plt.yticklabels(objects)
            plt.xlabel('Frequency')
            plt.ylabel(x)
            plt.show()
            
        if x in hist_labels:
        
            plt.hist(df[x],bins = 20)
            plt.ylabel('Sum')
            plt.xlabel(x)
            plt.show()
            
            
    def plot_double(self,feature_display,feature_split,object_split): 
    
        bar_labels = ['body_type','diet','drinks','drugs','education','ethnicity','job','offspring','orientation','pets','religion','sex','sign','smokes','status']
        hist_labels = ['age','height','income']
    
        if feature_display in bar_labels:
        
            df_new = df[df[feature_split] == object_split]
            
            objects = new_df[feature_display].unique()
            objects = sorted(objects)
            x_pos = np.arange(len(objects))
            counter = new_df[feature_display].groupby(x).size()
            counter.sort_values()
            print(counter)

            freq = []

            for i in range(len(counter)):
                
                freq.append(counter[i])
            
            plt.barh(x_pos,counter)
            plt.yticks(range(len(objects)),objects)
            #plt.yticklabels(objects)
            plt.xlabel('Frequency')
            plt.ylabel(feature_display)
            plt.show()
            
        if feature_display in hist_labels:
            
            df_new = df[df[feature_split] == object_split]
            
            print(df_new.head())
            plt.hist(df_new[feature_display],bins = 80)
            plt.ylabel('Frequency')
            plt.xlabel(feature_display)
            plt.show()
            
      
    # Predicts labels given data inputs   
    def predict(self):
    
        X = []
        
        for i in range(len(self.data_features)):
        
            #print(range(len(self.data_features)))
            print(self.data_features[i])
        
            answer = input('What is your %s? ' % self.data_features[i])
            
            X.append((int(answer) - min(df[self.data_features[i]]))/(max(df[self.data_features[i]]) - min(df[self.data_features[i]])))
            
        print(X)
        #income = input('What is your income in $? ')
        #height = input('What is your height in inches? ')
        
        #income = (int(income) - min(df[self.data_features[0]]))/(max(df[self.data_features[0]]) - min(df[self.data_features[0]]))
    
        #height = (int(height) - min(df[self.data_features[1]]))/(max(df[self.data_features[1]]) - min(df[self.data_features[1]]))
        
        accuracy, classifier = self.training()
        
        prediction = classifier.predict([X])
        
        for key, value in self.label_binarized_mapping.items():
            if value == prediction:
                return key
    
    # Gives validation metrics for a classification technique of accuracy, recall, precision and F1    
    def validation(self):
    
        accuracy,classifier = self.training()
    
        print(accuracy_score(self.dependent_test,self.guesses))
        print(recall_score(self.dependent_test,self.guesses))
        print(precision_score(self.dependent_test,self.guesses))
        print(f1_score(self.dependent_test,self.guesses))
        
        
        

# Classifies supervised data usung the K-Nearest technique
class k_nearest(dating_app):
    
    # Import trainign and test data from dating_app
    def __init__(self,data_features,label_feature):
    
        dating_app.__init__(self,data_features,label_feature)
        
        
    # Trains the classifier using training data given nearest neighbours k    
    def training(self,k):
    
        classifier = KNeighborsClassifier(n_neighbors = k)
    
        classifier.fit(self.independent_train,self.dependent_train)
    
        accuracy = classifier.score(self.independent_test,self.dependent_test)
        
        self.guesses = classifier.predict(self.independent_test)
    
        return accuracy, classifier
        
    
    # Finds the optimal k in terms of accuracy
    def k_optimal(self):
    
        accuracy = []
    
        for k in range(1,10):
    
            accuracy.append(self.training(k)[0])
        
        plt.plot(range(1,10),accuracy)
        plt.xlabel('k')
        plt.ylabel('Accuracy')
        plt.show()
        
        max_index = accuracy.index(max(accuracy))
        
        k_optimal = max_index + 1
    
        return k_optimal
    
    
    # Predicts labels given input data
    def predict(self):
    
        income = input('What is your income in $? ')
        height = input('What is your height in inches? ')
        
        income = (int(income) - min(df[self.data_features[0]]))/(max(df[self.data_features[0]]) - min(df[self.data_features[0]]))
    
        height = (int(height) - min(df[self.data_features[1]]))/(max(df[self.data_features[1]]) - min(df[self.data_features[1]]))
    
        k_chosen = self.k_optimal()
        
        accuracy, classifier = self.training(k_chosen)
        
        prediction = classifier.predict([[income,height]])
        
        for key, value in self.label_binarized_mapping.items():
            if value == prediction:
                return key
    
    # Gives validation metrics    
    def validation(self):
    
        k_chosen = self.k_optimal()
    
        accuracy,classifier = self.training(k_chosen)
    
        print(accuracy_score(self.dependent_test,self.guesses))
        print(recall_score(self.dependent_test,self.guesses))
        print(precision_score(self.dependent_test,self.guesses))
        print(f1_score(self.dependent_test,self.guesses))
                
                
# Logistic regression supervised classification technique              
class logistic_regression(dating_app):

    def __init__(self,data_features,label_feature):
    
        dating_app.__init__(self,data_features,label_feature)
        
    def training(self):
    
        classifier = LogisticRegression()
        
        classifier.fit(self.independent_train,self.dependent_train)
        
        accuracy = classifier.score(self.independent_test,self.dependent_test)
        
        self.guesses = classifier.predict(self.independent_test)
        
            
    
        return accuracy, classifier
       
        
# Support vector machine supervised classification technique    
class support_vector_machines(dating_app):

    def __init__(self,data_features,label_feature):
    
        dating_app.__init__(self,data_features,label_feature)
        
    def training(self):
    
        classifier = svm.SVC(kernel='linear')
        
        classifier.fit(self.independent_train,self.dependent_train)
        
        accuracy = classifier.score(self.independent_test,self.dependent_test)
        
        self.guesses = classifier.predict(self.independent_test)
    
        return accuracy, classifier
        
# Decision tree supervised classification technique
class decision_tree(dating_app):

    def __init__(self,data_features,label_feature):
    
        dating_app.__init__(self,data_features,label_feature)
        
    def training(self):
    
        classifier = DecisionTreeClassifier()
        
        classifier.fit(self.independent_train,self.dependent_train)
        
        accuracy = classifier.score(self.independent_test,self.dependent_test)
        self.guesses = classifier.predict(self.independent_test)
    
        return accuracy, classifier
        
# Random forest supervised classification technique               
class random_forest(dating_app):

    def __init__(self,data_features,label_feature):
    
        dating_app.__init__(self,data_features,label_feature)
        
    def training(self):
    
        classifier = RandomForestClassifier(n_estimators = 100)
        
        classifier.fit(self.independent_train,self.dependent_train)
        
        accuracy = classifier.score(self.independent_test,self.dependent_test)
        
        self.guesses = classifier.predict(self.independent_test)
        
        coefficient = classifier.feature_importances_
        
        print(coefficient)
        
        x_pos = np.arange(len(coefficient))
        
        plt.barh(x_pos,coefficient)
        plt.yticks(range(len(coefficient)),self.data_features)
        #plt.yticklabels(objects)
        plt.xlabel('Value')
        plt.ylabel('Feature')
        plt.show()
    
        return accuracy, classifier
 
# K-means unsupervised classification technique 
class k_means(dating_app):

    def __init__(self,data_features,label_feature):
        
        dating_app.__init__(self,data_features,label_feature)
        
    def training(self):
    
        model = KMeans(n_clusters=len(self.feature_objects))
        
        model.fit(self.independent_train)
        
        # Unsure if this is the correct way to assess accuracy
        self.guesses = model.predict(self.independent_test)
        
        accuracy = model.score(self.independent_test,self.dependent_test)
        
        
    
        return accuracy, model

# Naive-Bayes supervised classification technique      
class naive_bayes(dating_app):

    def  __init__(self):
        
        pass
        
    def training(self,essay_number,label_feature):
    
        
        
        df.fillna({essay_number:'NA'},inplace=True)  
        
        list_of_emails = df[essay_number]
        
        print(list_of_emails.isna().any())
        
    
        self.binarized_list = ['body_type', 'diet', 'drinks', 'drugs', 'education', 'ethnicity', 'job',
       'last_online', 'location', 'offspring', 'orientation', 'pets',
       'religion', 'sex', 'sign', 'smokes', 'speaks', 'status']
    
    
        self.label_binarized_df = pd.DataFrame()
       
        self.label_binarized_mapping = dict()         
            
        self.feature_objects = df[label_feature].unique()
            
        #print(self.feature_objects)

        for n in range(len(self.feature_objects)):

            self.label_binarized_mapping.update({self.feature_objects[n]:n})
    
            self.label_binarized_df = df[label_feature].map(self.label_binarized_mapping) 
            
            
                
        self.labels_normalised = pd.DataFrame()
    
        minimum_dependent = min(self.label_binarized_df)
        maximum_dependent = max(self.label_binarized_df)
    
        self.labels_normalised = self.label_binarized_df.apply(lambda x: (x - minimum_dependent)/(maximum_dependent - minimum_dependent))
        
        self.labels_normalised.fillna({label_feature:0},inplace=True)        
    
        
        self.independent_train, self.independent_test, self.dependent_train, self.dependent_test = train_test_split(list_of_emails,self.labels_normalised,train_size = 0.8)
        
        #print(self.independent_train.head())
        
        vectorizer = CountVectorizer()
        
        vectorizer.fit(self.independent_train)
            
        
        counts_train = vectorizer.transform(self.independent_train)
        
        print('yay')
        
        model = MultinomialNB()
        
        
        model.fit(counts_train,self.dependent_train)
        
       
        
        counts_test = vectorizer.transform(self.independent_test)
        
        #print(counts_test[1:10])
        
        self.guesses = model.predict(counts_test)
        
        accuracy = model.score(counts_test,self.dependent_test)
        
        return accuracy, model
        
# Perceptron supervised classification technique       
class perceptron(dating_app):

    def __init__(self,data_features,label_feature):
    
        dating_app.__init__(self,data_features,label_feature)
        
    def training(self):
    
        model = MLPRegressor()
        
        model.fit(self.independent_train,self.dependent_train)
        
        self.guesses = model.predict(self.independent_test)
        
        accuracy = model.score(self.independent_test,self.dependent_test)
        
        return accuracy, model
        
        

#print(random_forest(['income','height'],'sex').validation())
#print(decision_tree(['income','height'],'sex').validation())
#print(support_vector_machines(['income','height'],'sex').validation())
#print(logistic_regression(['income','height'],'sex').validation())
#print(k_nearest(['income','height'],'sex').validation())

print(df.columns)

#for word in ['age','body_type','diet','drinks','drugs','education','job','offspring','orientation','pets','religion','smokes','status']:

#print(logistic_regression(['height','age','body_type', 'diet', 'ethnicity', 'job',
       #'last_online', 'location', 'religion', 'sign', 'speaks'],'sex').validation())
#print(random_forest(['height','age','body_type', 'diet', 'ethnicity', 'job',
       #'last_online', 'location', 'religion', 'sign', 'speaks'],'sex').validation())
       
print(naive_bayes().training('essay0','sex'))