import pandas as pd

#ticker_list = pd.read_csv('ticker_list.csv')
#current_df = pd.read_csv("current_features_FTSE_100.csv")
#index_df = pd.read_csv("Historic_FTSE_100_index_values.csv")

def colourCode(current_df):
    
    
    #print(current_df.head())
    
    current_df_normalised = pd.DataFrame()
    current_df_numbered = pd.DataFrame()
    
    for i in range(len(current_df.columns)):
        #for j in range(len(current_df)):
            #print(current_df.iloc[j,i])
        #print(min(current_df[current_df.columns[i]]))
            #x = (current_df.iloc[j,i] - min(current_df[current_df.columns[i]]))/(max(current_df[current_df.columns[i]])-min(current_df[current_df.columns[i]]))
        
        
        #print(type(max(current_df[current_df.columns[i]])-min(current_df[current_df.columns[i]])))
        #print(current_df.columns[i])
        
        if current_df.columns[i] in ['Ticker','Industry']:
            current_df_numbered[current_df.columns[i]] = current_df[current_df.columns[i]]
        else:
            current_df_normalised[current_df.columns[i]] = current_df.apply(lambda row: (row[current_df.columns[i]] - min(current_df[current_df.columns[i]]))/(max(current_df[current_df.columns[i]])-min(current_df[current_df.columns[i]])),axis=1)
    
            current_df_numbered[current_df.columns[i]] = current_df_normalised.apply(lambda row: round(row[current_df.columns[i]] * 10),axis = 1)
        
    return(current_df_numbered)
		
		
		
		
#colourCode()